package com.zgenit.unim.struktural.ukm;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.UkmModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditInfoUkmActivity extends AppCompatActivity {

    @BindView(R.id.nama)
    EditText t_nama;
    @BindView(R.id.deskripsi)
    EditText t_deskripsi;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String nama, deskripsi, kd_ukm;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_info_ukm);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        kd_ukm = sharedPreferences.getString("kd_ukm", "");

        getDetail(kd_ukm);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(EditInfoUkmActivity.this, StrukturalUkmActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(intent);
            }
        });

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nama = t_nama.getText().toString();
                deskripsi = t_deskripsi.getText().toString();
                if(nama.equals("") || deskripsi.equals("")){
                    Toast.makeText(EditInfoUkmActivity.this, "Semua filed harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    UkmApi ukmApi= Retro.ukmRetro();
                    ukmApi.editUkm(kd_ukm, nama, deskripsi).enqueue(new Callback<UkmModel>() {
                        @Override
                        public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1){
                                Toast.makeText(EditInfoUkmActivity.this, "Info Ukm berhasil diubah", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<UkmModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(EditInfoUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    public void getDetail(String kd_ukm){
        final UkmApi ukmApi = Retro.ukmRetro();
        ukmApi.detailUkm(kd_ukm).enqueue(new Callback<UkmModel>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                if(response.body().getCode() == 1){
                    t_nama.setText(response.body().getNama_ukm());
                    t_deskripsi.setText(response.body().getDeskripsi());
                }else{
                    Toast.makeText(EditInfoUkmActivity.this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UkmModel> call, Throwable t) {
                Toast.makeText(EditInfoUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
