package com.zgenit.unim;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.budiyev.android.codescanner.ErrorCallback;
import com.google.zxing.Result;
import com.zgenit.unim.api.AuthApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.UserModel;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ScanQrActivity extends BaseActivity {

    private static final int RC_PERMISSION = 10;
    private CodeScanner mCodeScanner;
    private boolean mPermissionGranted;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scan_qr);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);
        CodeScannerView codeScannerView = findViewById(R.id.scanner);
        mCodeScanner = new CodeScanner(ScanQrActivity.this, codeScannerView);
        mCodeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@androidx.annotation.NonNull final Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        progressDialog.show();
                        if(result.getText().contains("<><>")){
                        final String[] split = result.getText().split("<><>");
                        final AuthApi authApi = Retro.authRetro();
                        authApi.login(split[0],split[1],split[2]).enqueue(new Callback<UserModel>() {
                            @Override
                            public void onResponse(Call<UserModel> call, Response<UserModel> response) {
                                progressDialog.dismiss();
                                if(response.body().getCode() == 1){
                                    SharedPreferences sharedPreferences = getSharedPreferences("Unim", Context.MODE_PRIVATE);
                                    SharedPreferences.Editor editor = sharedPreferences.edit();
                                    editor.putString("id", response.body().getId());
                                    editor.putString("name", response.body().getUser());
                                    editor.putString("kd_ukm", response.body().getKd_ukm());
                                    editor.putString("role", split[2]);
                                    editor.apply();
                                    startActivity(new Intent(ScanQrActivity.this, MainActivity.class));
                                }else{
                                    Toast.makeText(ScanQrActivity.this, "Code Tidak Sesuai", Toast.LENGTH_SHORT).show();
                                    mCodeScanner.startPreview();
                                }
                            }

                            @Override
                            public void onFailure(Call<UserModel> call, Throwable t) {
                                progressDialog.dismiss();
                                Toast.makeText(ScanQrActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                                mCodeScanner.startPreview();
                            }
                        });
                        }else{
                            progressDialog.dismiss();
                            Toast.makeText(ScanQrActivity.this, "Code Tidak Sesuai", Toast.LENGTH_SHORT).show();
                            mCodeScanner.startPreview();
                        }
                    }
                });
            }
        });
        mCodeScanner.setErrorCallback(new ErrorCallback() {
            @Override
            public void onError(@androidx.annotation.NonNull final Exception error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(ScanQrActivity.this, error.toString(), Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            if (checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                mPermissionGranted = false;
                requestPermissions(new String[] {Manifest.permission.CAMERA}, RC_PERMISSION);
            } else {
                mPermissionGranted = true;
            }
        } else {
            mPermissionGranted = true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == RC_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                mPermissionGranted = true;
                mCodeScanner.startPreview();
            } else {
                mPermissionGranted = false;
            }
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (mPermissionGranted) {
            mCodeScanner.startPreview();
        }
    }

    @Override
    protected void onPause() {
        mCodeScanner.releaseResources();
        super.onPause();
    }
}
