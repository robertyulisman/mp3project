package com.zgenit.unim.pembina.konfirmasi;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.adapter.StrukturalAdapter;
import com.zgenit.unim.admin.InfoAnggotaActivity;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.StrukturalApi;
import com.zgenit.unim.api.model.StrukturalModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PembinaStrukturalActivity extends AppCompatActivity {

    @BindView(R.id.rv_struktural)
    RecyclerView rv_struktural;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    ArrayList<StrukturalModel> StrukturalModelArrayList;
    StrukturalAdapter StrukturalAdapter;
    String kd_ukm;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembina_struktural);
        ButterKnife.bind(this);

        message.setText("Sedang Memproses...");

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        kd_ukm = sharedPreferences.getString("kd_ukm", "");

        getStruktural(kd_ukm);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaStrukturalActivity.this, PembinaKonfirmasiActivity.class));
            }
        });

    }

    private void getStruktural(String kd_ukm){
        final StrukturalApi strukturalApi = Retro.strukturalRetro();
        strukturalApi.getPengajuan(kd_ukm, "Meminta").enqueue(new Callback<ArrayList<StrukturalModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<StrukturalModel>> call, Response<ArrayList<StrukturalModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    StrukturalModelArrayList = new ArrayList<>();
                    StrukturalModelArrayList = response.body();
                    StrukturalAdapter = new StrukturalAdapter(PembinaStrukturalActivity.this, StrukturalModelArrayList);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(PembinaStrukturalActivity.this);
                    rv_struktural.setLayoutManager(layoutManager);
                    rv_struktural.setAdapter(StrukturalAdapter);
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<StrukturalModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(PembinaStrukturalActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
