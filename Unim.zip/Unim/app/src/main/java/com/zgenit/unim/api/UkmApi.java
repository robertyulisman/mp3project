package com.zgenit.unim.api;

import com.zgenit.unim.api.model.UkmModel;
import com.zgenit.unim.api.model.UserModel;

import java.util.ArrayList;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface UkmApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<UserModel> getOneRute();

    @GET("ukm/index")
    Call<ArrayList<UkmModel>> getUkm();

    @GET("ukm/mine/{id_anggota}")
    Call<ArrayList<UkmModel>> getMine(@Path("id_anggota") String id_anggota);

    @GET("ukm/follow/{id_anggota}")
    Call<ArrayList<UkmModel>> getFollow(@Path("id_anggota") String id_anggota);

    @GET("ukm/agenda/{kd_ukm}")
    Call<UkmModel> getAgenda(@Path("kd_ukm") String kd_ukm);

//    @FormUrlEncoded
//    @POST("ukm/add")
//    Call<UkmModel> addUkm(
//            @Field("nama_ukm") String nama_ukm,
//            @Field("id_pem") String id_pem,
//            @Field("id_struk") String id_struk,
//            @Field("deskripsi") String deskripsi
//    );

    @Multipart
    @POST("ukm/add")
    Call<UkmModel> addUkm(
            @Part("nama_ukm") RequestBody name,
            @Part("deskripsi") RequestBody deskripsi,
            @Part("id_pem") RequestBody id_pem,
            @Part("id_struk") RequestBody id_struk,
            @Part MultipartBody.Part photo
    );

    @FormUrlEncoded
    @POST("ukm/edit")
    Call<UkmModel> editUkm(
            @Field("kd_ukm") String kd_ukm,
            @Field("nama_ukm") String nama_ukm,
            @Field("deskripsi") String deskripsi
    );

    @GET("ukm/rekap/{kd_ukm}")
    Call<UkmModel> getRekap(@Path("kd_ukm") String kd_ukm);

    @FormUrlEncoded
    @POST("ukm/daftar")
    Call<UkmModel> daftarUkm(
            @Field("id_anggota") String id_anggota,
            @Field("kd_ukm") String kd_ukm
    );

    @GET("ukm/detail/{kd_ukm}")
    Call<UkmModel> detailUkm(@Path("kd_ukm") String kd_ukm);
}