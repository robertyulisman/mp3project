package com.zgenit.unim.pembina.konfirmasi;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.anggota.pengaturan.saran.BuatSaranActivity;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.SaranApi;
import com.zgenit.unim.api.StrukturalApi;
import com.zgenit.unim.api.model.StrukturalModel;
import com.zgenit.unim.api.model.StrukturalModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AkunStrukturalActivity extends AppCompatActivity {

    @BindView(R.id.user)
    AppCompatEditText t_user;
    @BindView(R.id.pass)
    AppCompatEditText t_pass;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String user, pass;
    int id;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_akun_struktural);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        id = getIntent().getIntExtra("id",0);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AkunStrukturalActivity.this, PembinaStrukturalActivity.class));
            }
        });

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user= t_user.getText().toString();
                pass= t_pass.getText().toString();
                if(user.equals("") || pass.equals("")){
                    Toast.makeText(AkunStrukturalActivity.this, "Semua filed harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    final StrukturalApi strukturalApi = Retro.strukturalRetro();
                    strukturalApi.add(id, user, pass).enqueue(new Callback<StrukturalModel>() {
                        @Override
                        public void onResponse(Call<StrukturalModel> call, Response<StrukturalModel> response) {
                            if(response.body().getCode() == 1){
                                strukturalApi.update(id, "Diterima").enqueue(new Callback<StrukturalModel>() {
                                    @Override
                                    public void onResponse(Call<StrukturalModel> call, Response<StrukturalModel> response) {
                                        if(response.body().getCode() == 1){
                                            progressDialog.dismiss();
                                            Toast.makeText(AkunStrukturalActivity.this, "Pengajuan Struktural Telah Dikonfirmasi", Toast.LENGTH_SHORT).show();
                                            Handler handler = new Handler();
                                            handler.postDelayed(new Runnable() {
                                                @Override
                                                public void run() {
                                                    startActivity(new Intent(AkunStrukturalActivity.this, PembinaStrukturalActivity.class));
                                                }
                                            },1000);
                                        }
                                    }

                                    @Override
                                    public void onFailure(Call<StrukturalModel> call, Throwable t) {
                                        progressDialog.dismiss();
                                        Toast.makeText(AkunStrukturalActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                                    }
                                });
                            }else{
                                progressDialog.dismiss();
                                Toast.makeText(AkunStrukturalActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<StrukturalModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(AkunStrukturalActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
