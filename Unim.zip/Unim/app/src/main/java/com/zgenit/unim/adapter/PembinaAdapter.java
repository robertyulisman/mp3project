package com.zgenit.unim.adapter;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.admin.mahasiswa.EditMahasiswaActivity;
import com.zgenit.unim.admin.pembina.EditPembinaActivity;
import com.zgenit.unim.agenda.AgendaDetailActivity;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.PembinaModel;
import com.zgenit.unim.api.model.PembinaModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PembinaAdapter extends RecyclerView.Adapter<PembinaAdapter.MyViewHolder> {

    private Context context;
    private List<PembinaModel> PembinaModels;

    public PembinaAdapter(Context context, ArrayList<PembinaModel> PembinaModels) {
        this.context = context;
        this.PembinaModels = PembinaModels;
    }

    @NonNull
    @Override
    public PembinaAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.pembina_list,
                viewGroup, false);
        return new PembinaAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final PembinaAdapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.nama.setText(PembinaModels.get(i).getNama());
        myViewHolder.no_telp.setText(PembinaModels.get(i).getNo_telp());
        myViewHolder.btn_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(myViewHolder.itemView.getContext(), EditPembinaActivity.class);
                intent.putExtra("id_pem", PembinaModels.get(i).getId_pem());
                myViewHolder.itemView.getContext().startActivity(intent);
            }
        });
        myViewHolder.btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final AlertDialog.Builder builder = new AlertDialog.Builder(myViewHolder.itemView.getContext());
                builder.setTitle("Konfirmasi Hapus");
                builder.setMessage("Yakin ingin menghapus data ini ?");
                builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialogInterface, int id) {
                        final AnggotaApi anggotaApi = Retro.anggotaRetro();
                        anggotaApi.deletePembina(PembinaModels.get(i).getId_pem()).enqueue(new Callback<PembinaModel>() {
                            @Override
                            public void onResponse(Call<PembinaModel> call, Response<PembinaModel> response) {
                                if (response.body().getCode() == 1) {
                                    Toast.makeText(myViewHolder.itemView.getContext(), "Data sukses dihapus", Toast.LENGTH_SHORT).show();
                                    PembinaModels.remove(i);
                                    notifyDataSetChanged();
                                } else {
                                    Toast.makeText(myViewHolder.itemView.getContext(), response.body().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<PembinaModel> call, Throwable t) {
                                Toast.makeText(myViewHolder.itemView.getContext(), "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return PembinaModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.pembina)
        LinearLayout pembina;
        @BindView(R.id.nama)
        TextView nama;
        @BindView(R.id.no_telp)
        TextView no_telp;
        @BindView(R.id.btn_edit)
        Button btn_edit;
        @BindView(R.id.btn_delete)
        Button btn_delete;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public void filterList(List<PembinaModel> pembinaModels){
        this.PembinaModels = pembinaModels;
        notifyDataSetChanged();
    }
}
