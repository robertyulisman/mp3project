package com.zgenit.unim.pembina.pengaturan;

import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.anggota.pengaturan.AnggotaProfileActivity;
import com.zgenit.unim.anggota.pengaturan.UpdatePasswordActivity;
import com.zgenit.unim.anggota.pengaturan.saran.BuatSaranActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PembinaPengaturanActivity extends AppCompatActivity {

    @BindView(R.id.profile)
    LinearLayout profile;
    @BindView(R.id.password)
    LinearLayout password;
    @BindView(R.id.saran)
    LinearLayout saran;
    @BindView(R.id.btn_back)
    ImageView btn_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anggota_pengaturan);
        ButterKnife.bind(this);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaPengaturanActivity.this, MainActivity.class));
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaPengaturanActivity.this, PembinaProfileActivity.class));
            }
        });
        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaPengaturanActivity.this, UpdatePasswordActivity.class));
            }
        });
        saran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaPengaturanActivity.this, BuatSaranActivity.class));
            }
        });
    }
}
