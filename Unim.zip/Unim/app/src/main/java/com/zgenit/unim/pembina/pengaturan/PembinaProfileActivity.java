package com.zgenit.unim.pembina.pengaturan;

import android.Manifest;
import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.makeramen.roundedimageview.RoundedImageView;
import com.zgenit.unim.AuthActivity;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.admin.ukm.AddUkmActivity;
import com.zgenit.unim.anggota.pengaturan.AnggotaPengaturanActivity;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UriApi;
import com.zgenit.unim.api.UserApi;
import com.zgenit.unim.api.model.PembinaModel;
import com.zgenit.unim.api.model.UkmModel;
import com.zgenit.unim.api.model.UserModel;

import java.io.File;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PembinaProfileActivity extends AppCompatActivity {

    @BindView(R.id.nama)
    AppCompatEditText t_nama;
    @BindView(R.id.telp)
    AppCompatEditText t_telp;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.photo)
    RoundedImageView t_photo;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    Bitmap bitmap;
    String nama, telp, id_pem, photo, role;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembina_profile);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        id_pem = sharedPreferences.getString("id", "");
        role = sharedPreferences.getString("role", "");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaProfileActivity.this, AnggotaPengaturanActivity.class));
            }
        });

        getDetail();

        t_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ActivityCompat.checkSelfPermission(PembinaProfileActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(PembinaProfileActivity.this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                }
                else
                {
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, 200);
                }
            }
        });

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nama = t_nama.getText().toString();
                telp = t_telp.getText().toString();
                if(nama.equals("") || telp.equals("")){
                    Toast.makeText(PembinaProfileActivity.this, "Semua filed harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    UserApi userApi = Retro.userRetro();
                    userApi.profilePembina(id_pem, nama, telp).enqueue(new Callback<UserModel>() {
                        @Override
                        public void onResponse(Call<UserModel> call, Response<UserModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1){
                                Toast.makeText(PembinaProfileActivity.this, "Profile Berhasil Diubah", Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<UserModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(PembinaProfileActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    public void getDetail(){
        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        id_pem= sharedPreferences.getString("id", "");
        AnggotaApi anggotaApi = Retro.anggotaRetro();
        anggotaApi.onePembina(id_pem).enqueue(new Callback<PembinaModel>() {
            @Override
            public void onResponse(Call<PembinaModel> call, Response<PembinaModel> response) {
                if(response.body().getCode() == 1){
                    t_nama.setText(response.body().getNama());
                    t_telp.setText(response.body().getNo_telp());
                    Glide.with(PembinaProfileActivity.this)
                            .load(UriApi.IMG_URL+"pembina/"+response.body().getPhoto())
                            .error(R.color.colorPhoto)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(t_photo);
                }
            }

            @Override
            public void onFailure(Call<PembinaModel> call, Throwable t) {

            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == 200)
        {
            Cursor cursor = PembinaProfileActivity.this.getContentResolver().query(data.getData(), null,null,null,null);
            if(cursor==null)
            {
                photo = data.getData().getPath();
            }
            else
            {
                cursor.moveToFirst();
                int imgIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATA);
                photo = cursor.getString(imgIndex);
            }
            if(photo!=null)
            {
                File imageFile = new File(photo);
                bitmap =  BitmapFactory.decodeFile(imageFile.getAbsolutePath());

                int nh = (int) (bitmap.getHeight() * (512.0 / bitmap.getWidth()));
                bitmap = Bitmap.createScaledBitmap(bitmap, 512, nh, true);
                AlertDialog.Builder builder = new AlertDialog.Builder(PembinaProfileActivity.this);
                builder.setTitle("Konfirmasi");
                builder.setMessage("Yakin ingin mengganti foto profil ?");
                builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialogInterface, int id) {
                        progressDialog.show();
                        File imagefile = new File(photo);
                        final RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-file"), imagefile);
                        RequestBody r_id = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(id_pem));
                        RequestBody r_role = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(role));
                        MultipartBody.Part part = MultipartBody.Part.createFormData("photo", imagefile.getName(), requestBody);

                        UserApi userApi = Retro.userRetro();
                        userApi.editPhoto(r_id, r_role, part).enqueue(new Callback<UkmModel>() {
                            @Override
                            public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                                progressDialog.dismiss();
                                if(response.body().getCode() == 1){
                                    Toast.makeText(PembinaProfileActivity.this, "Foto profil berhasil diubah", Toast.LENGTH_SHORT).show();
                                }else{
                                    Toast.makeText(PembinaProfileActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<UkmModel> call, Throwable t) {
                                progressDialog.dismiss();
                                Toast.makeText(PembinaProfileActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                            }
                        });
                        t_photo.setImageBitmap(bitmap);
                    }
                });
                builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
            else
            {
                Toast.makeText(PembinaProfileActivity.this, "Kesalahan Saat Mengambil File", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 1)
        {
            if(grantResults.length > 0)
            {
                StringBuffer stringBuffer = new StringBuffer();
                int grantResult = grantResults[0];
                if(grantResult==PackageManager.PERMISSION_GRANTED)
                {
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, 200);
                }
            }
        }
    }
}
