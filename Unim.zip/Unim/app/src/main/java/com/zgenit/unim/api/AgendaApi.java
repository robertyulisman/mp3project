package com.zgenit.unim.api;

import com.zgenit.unim.api.model.AgendaModel;
import com.zgenit.unim.api.model.PembinaModel;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface AgendaApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<AgendaModel> getOneRute();

    @GET("agenda/index")
    Call<ArrayList<AgendaModel>> getAgenda();

    @GET("agenda/mine/{id_anggota}")
    Call<ArrayList<AgendaModel>> getMine(@Path("id_anggota") String id_anggota);

    @GET("agenda/follow/{id_anggota}")
    Call<ArrayList<AgendaModel>> getFollow(@Path("id_anggota") String id_anggota);

    @GET("agenda/ukm/{kd_ukm}")
    Call<ArrayList<AgendaModel>> getPerUkm(@Path("kd_ukm") String kd_ukm);

    @GET("agenda/get/{kd_agenda}")
    Call<AgendaModel> oneAgenda(@Path("kd_agenda") String kd_agenda);

    @FormUrlEncoded
    @POST("agenda/add")
    Call<AgendaModel> addAgenda(
            @Field("kd_ukm") String kd_ukm,
            @Field("nama_keg") String nama_keg,
            @Field("jns_keg") String jns_keg,
            @Field("tgl_keg") String tgl_keg,
            @Field("jam") String jam,
            @Field("tempat") String tempat
    );

    @FormUrlEncoded
    @POST("agenda/ikuti")
    Call<UkmModel> ikutAgenda(
            @Field("kd_agenda") String kd_agenda,
            @Field("id_anggota") String id_anggota
    );

    @GET("agenda/rekap/{id_anggota}")
    Call<ArrayList<AgendaModel>> rekapAgenda(@Path("id_anggota") String id_anggota);

    @GET("agenda/pengajuan/{kd_ukm}")
    Call<ArrayList<AgendaModel>> pengajuanAgenda(@Path("kd_ukm") String kd_ukm);

    @GET("agenda/pengajuandetail/{id}")
    Call<AgendaModel> pengajuanDetail(@Path("id") String id);

    @FormUrlEncoded
    @POST("agenda/ajukan")
    Call<AgendaModel> ajukanAgenda(
            @Field("pengirim") String pengirim,
            @Field("kd_ukm") String kd_ukm,
            @Field("nama_keg") String nama_keg,
            @Field("jns_keg") String jns_keg,
            @Field("tgl_keg") String tgl_keg,
            @Field("jam") String jam,
            @Field("tempat") String tempat
    );

    @FormUrlEncoded
    @POST("agenda/setujui")
    Call<AgendaModel> setujuiAgenda(
            @Field("id") String id,
            @Field("status") String status
    );
}

