package com.zgenit.unim.admin.saran;

import android.annotation.SuppressLint;
import android.content.Intent;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.adapter.SaranAdapter;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.SaranApi;
import com.zgenit.unim.api.model.SaranModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SaranMaukActivity extends AppCompatActivity {

    @BindView(R.id.rv_saran)
    RecyclerView rv_saran;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    ArrayList<SaranModel> SaranModelArrayList;
    SaranAdapter SaranAdapter;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_saran_mauk);
        ButterKnife.bind(this);

        message.setText("Sedang Memproses...");

        getSaran();

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SaranMaukActivity.this, MainActivity.class));
            }
        });
    }

    private void getSaran(){
        final SaranApi saranApi = Retro.saranRetro();
        saranApi.getSaran().enqueue(new Callback<ArrayList<SaranModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<SaranModel>> call, Response<ArrayList<SaranModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    SaranModelArrayList = new ArrayList<>();
                    SaranModelArrayList = response.body();
                    SaranAdapter = new SaranAdapter(SaranMaukActivity.this, SaranModelArrayList);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(SaranMaukActivity.this);
                    rv_saran.setLayoutManager(layoutManager);
                    rv_saran.setAdapter(SaranAdapter);
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<SaranModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(SaranMaukActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
