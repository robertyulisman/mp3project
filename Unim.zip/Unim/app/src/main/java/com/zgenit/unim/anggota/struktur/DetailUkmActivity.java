package com.zgenit.unim.anggota.struktur;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.makeramen.roundedimageview.RoundedImageView;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.UriApi;
import com.zgenit.unim.api.model.UkmModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.bumptech.glide.load.engine.DiskCacheStrategy.ALL;

public class DetailUkmActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.ukm)
    TextView ukm;
    @BindView(R.id.jumlah)
    TextView jumlah;
    @BindView(R.id.pembina)
    TextView pembina;
    @BindView(R.id.ketua)
    TextView ketua;
    @BindView(R.id.wakil)
    TextView wakil;
    @BindView(R.id.sekretaris)
    TextView sekretaris;
    @BindView(R.id.bendahara)
    TextView bendahara;
    @BindView(R.id.anggota)
    TextView anggota;
    @BindView(R.id.photo)
    RoundedImageView photo;
    String kd_ukm, role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_ukm);
        ButterKnife.bind(this);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        role = sharedPreferences.getString("role", "");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(role.equals("Anggota")) {
                    startActivity(new Intent(DetailUkmActivity.this, AnggotaStrukturActivity.class));
                }else{
                    startActivity(new Intent(DetailUkmActivity.this, MainActivity.class));
                }
            }
        });
        kd_ukm = getIntent().getStringExtra("kd_ukm");
        getDetail(kd_ukm);
    }

    public void getDetail(String kd_ukm){
        final UkmApi ukmApi = Retro.ukmRetro();
        ukmApi.detailUkm(kd_ukm).enqueue(new Callback<UkmModel>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                if(response.body().getCode() == 1){
                    ukm.setText(response.body().getNama_ukm());
                    pembina.setText(response.body().getPembina());
                    ketua.setText(response.body().getKetua());
                    wakil.setText(response.body().getWakil());
                    sekretaris.setText(response.body().getSekretaris());
                    bendahara.setText(response.body().getBendahara());
                    jumlah.setText(response.body().getJumlah()+" orang");
                    Glide.with(DetailUkmActivity.this).load(UriApi.IMG_URL+"ukm/"+response.body().getPhoto())
                            .diskCacheStrategy(ALL)
                            .error(R.color.colorPhoto)
                            .into(photo);
                    String[] s_anggota = response.body().getAnggota().split(",");
                    StringBuilder r_anggota = new StringBuilder();
                    for(int i = 0; i < s_anggota.length; i++){
                        r_anggota = new StringBuilder((i+1) +". "+ r_anggota + s_anggota[i] + "\n");
                    }
                    anggota.setText(r_anggota.toString());
                }else{
                    Toast.makeText(DetailUkmActivity.this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UkmModel> call, Throwable t) {
                Toast.makeText(DetailUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
