package com.zgenit.unim.struktural.cetak;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UserApi;
import com.zgenit.unim.api.model.UserModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StrukturalCetakActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.id)
    TextView id;
    @BindView(R.id.user)
    TextView user;
    @BindView(R.id.jabatan)
    TextView jabatan;
    @BindView(R.id.periode)
    TextView periode;
    @BindView(R.id.qrcode)
    ImageView qrcode;
    String id_anggota, code,role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_struktural_cetak);
        ButterKnife.bind(this);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        id_anggota = sharedPreferences.getString("id", "");
        role = sharedPreferences.getString("role", "");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StrukturalCetakActivity.this, MainActivity.class));
            }
        });
        getDetail(id_anggota);
    }

    public void getDetail(String id_anggota){
        final UserApi userApi = Retro.userRetro();
        userApi.cetakUser(id_anggota).enqueue(new Callback<UserModel>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<UserModel> call, Response<UserModel> response) {
                if(response.body().getCode() == 1){
                    id.setText(response.body().getId());
                    user.setText(response.body().getUser());
                    jabatan.setText(response.body().getJabatan());
                    periode.setText(response.body().getPeriode());
                    code = response.body().getUser()+"<><>"+response.body().getPass()+"<><>"+role;
                    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                    try{
                        BitMatrix bitMatrix = multiFormatWriter.encode(code, BarcodeFormat.QR_CODE,300,300);
                        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                        qrcode.setImageBitmap(bitmap);
                    }catch(WriterException e){
                        System.out.println(e.getMessage());
                    }
                }else{
                    Toast.makeText(StrukturalCetakActivity.this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UserModel> call, Throwable t) {
                Toast.makeText(StrukturalCetakActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
