package com.zgenit.unim.admin.mahasiswa;

import android.app.ProgressDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.MahasiswaModel;

import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddMahasiswaActivity extends AppCompatActivity {

    @BindView(R.id.nim)
    AppCompatEditText t_nim;
    @BindView(R.id.nama)
    AppCompatEditText t_nama;
    @BindView(R.id.alamat)
    AppCompatEditText t_alamat;
    @BindView(R.id.ttl)
    AppCompatEditText t_ttl;
    @BindView(R.id.jkel)
    Spinner t_jkel;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String nim, nama, alamat, j_kel, ttl, pass;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_mahasiswa);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddMahasiswaActivity.this, DataMahasiswaActivity.class));
            }
        });
        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nim = Objects.requireNonNull(t_nim.getText()).toString();
                nama = Objects.requireNonNull(t_nama.getText()).toString();
                alamat = Objects.requireNonNull(t_alamat.getText()).toString();
                j_kel = t_jkel.getSelectedItem().toString();
                if(j_kel.equals("Laki-laki")){
                    j_kel = "L";
                }else if(j_kel.equals("Perempuan")){
                    j_kel = "P";
                }
                ttl = Objects.requireNonNull(t_ttl.getText()).toString();
                pass = "";

                if(nim.equals("") || nama.equals("") || alamat.equals("") || j_kel.equals("") || ttl.equals("")){
                    Toast.makeText(AddMahasiswaActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    final AnggotaApi anggotaApi = Retro.anggotaRetro();
                    anggotaApi.addMahasiswa(nim, nama, pass, alamat, j_kel, ttl).enqueue(new Callback<MahasiswaModel>() {
                        @Override
                        public void onResponse(Call<MahasiswaModel> call, Response<MahasiswaModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1 ){
                                Toast.makeText(AddMahasiswaActivity.this, "Data sukses ditambahkan", Toast.LENGTH_SHORT).show();
                                t_nim.setText("");
                                t_nama.setText("");
                                t_alamat.setText("");
                                t_ttl.setText("");
                                t_jkel.setSelection(0);
                            }else{
                                Toast.makeText(AddMahasiswaActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<MahasiswaModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(AddMahasiswaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
