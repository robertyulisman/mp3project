package com.zgenit.unim.anggota.struktural;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.StrukturalApi;
import com.zgenit.unim.api.model.StrukturalModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class FormStrukturalActivity extends AppCompatActivity {

    @BindView(R.id.jabatan)
    Spinner t_jabatan;
    @BindView(R.id.periode)
    AppCompatEditText t_periode;
    @BindView(R.id.visi)
    AppCompatEditText t_visi;
    @BindView(R.id.btn_kirim)
    Button btn_kirim;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String jabatan, periode, visi, id_anggota, kd_ukm;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_form_struktural);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        id_anggota = sharedPreferences.getString("id", "");
        kd_ukm = getIntent().getStringExtra("kd_ukm");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(FormStrukturalActivity.this, MainActivity.class));
            }
        });

        btn_kirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jabatan = t_jabatan.getSelectedItem().toString();
                periode = t_periode.getText().toString();
                visi = t_visi.getText().toString();
                if(jabatan.equals("Jabatan") || periode.equals("") || visi.equals("")){
                    Toast.makeText(FormStrukturalActivity.this, "Semua filed harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    StrukturalApi strukturalApi= Retro.strukturalRetro();
                    strukturalApi.ajukan(id_anggota, kd_ukm, jabatan, periode,visi).enqueue(new Callback<StrukturalModel>() {
                        @Override
                        public void onResponse(Call<StrukturalModel> call, Response<StrukturalModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1){
                                Toast.makeText(FormStrukturalActivity.this, "Pengajuan berhasil dikirimkan", Toast.LENGTH_SHORT).show();
                                t_jabatan.setSelection(0);
                                t_periode.setText("");
                                t_visi.setText("");
                            }else{
                                Toast.makeText(FormStrukturalActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<StrukturalModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(FormStrukturalActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
