package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class SaranModel {
    @SerializedName("id_saran")
    @Expose
    private int id_saran;
    @SerializedName("subject")
    @Expose
    private String subject;
    @SerializedName("pesan")
    @Expose
    private String pesan;
    @SerializedName("pengirim")
    @Expose
    private String pengirim;
    @SerializedName("nama")
    @Expose
    private String nama;
    @SerializedName("code")
    @Expose
    private Integer code;
    @SerializedName("message")
    @Expose
    private String message;

    public int getId_saran() { return id_saran; }
    public String getSubject() { return subject; }
    public String getPesan() { return pesan; }
    public String getPengirim() { return pengirim; }
    public String getNama() { return nama; }
    public Integer getCode() { return code; }
    public String getMessage() { return message; }
}
