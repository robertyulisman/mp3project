package com.zgenit.unim.pembina.konfirmasi;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;

import butterknife.BindView;
import butterknife.ButterKnife;

public class PembinaKonfirmasiActivity extends AppCompatActivity {

    @BindView(R.id.struktural)
    LinearLayout struktural;
    @BindView(R.id.diterima)
    LinearLayout diterima;
    @BindView(R.id.agenda)
    LinearLayout agenda;
    @BindView(R.id.btn_back)
    ImageView btn_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembina_konfirmasi);
        ButterKnife.bind(this);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaKonfirmasiActivity.this, MainActivity.class));
            }
        });

        struktural.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaKonfirmasiActivity.this, PembinaStrukturalActivity.class));
            }
        });
        diterima.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaKonfirmasiActivity.this, AktifStrukturalActivity.class));
            }
        });
        agenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaKonfirmasiActivity.this, KonfirmasiAgendaActivity.class));
            }
        });
    }
}
