package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class StrukturalModel {
    @SerializedName("id")
    @Expose
    private int id;
    @SerializedName("id_anggota")
    @Expose
    private String id_anggota;
    @SerializedName("kd_ukm")
    @Expose
    private String kd_ukm;
    @SerializedName("jabatan")
    @Expose
    private String jabatan;
    @SerializedName("periode")
    @Expose
    private String periode;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("visi")
    @Expose
    private String visi;
    @SerializedName("nama")
    @Expose
    private String nama;
    @SerializedName("code")
    @Expose
    private Integer code;
    @SerializedName("message")
    @Expose
    private String message;

    public int getId() { return id; }
    public String getId_anggota() { return id_anggota; }
    public String getKd_ukm() { return kd_ukm; }
    public String getJabatan() { return jabatan; }
    public String getPeriode() { return periode; }
    public String getVisi() { return visi; }
    public String getNama() { return nama;}
    public String getStatus() { return status;}
    public Integer getCode() { return code; }
    public String getMessage() { return message; }
}
