package com.zgenit.unim.anggota.pengaturan.saran;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.anggota.pengaturan.AnggotaPengaturanActivity;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.SaranApi;
import com.zgenit.unim.api.model.SaranModel;
import com.zgenit.unim.pembina.pengaturan.PembinaPengaturanActivity;
import com.zgenit.unim.struktural.pengaturan.StrukturalPengaturanActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BuatSaranActivity extends AppCompatActivity {

    @BindView(R.id.subject)
    EditText t_subject;
    @BindView(R.id.saran)
    EditText t_saran;
    @BindView(R.id.btn_kirim)
    Button btn_kirim;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String subject, saran, id_anggota, role;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buat_saran);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        id_anggota = sharedPreferences.getString("id", "");
        role = sharedPreferences.getString("role", "");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(role.equals("Pembina")){
                    startActivity(new Intent(BuatSaranActivity.this, PembinaPengaturanActivity.class));
                }else if(role.equals("Struktural")){
                    startActivity(new Intent(BuatSaranActivity.this, StrukturalPengaturanActivity.class));
                }else {
                    startActivity(new Intent(BuatSaranActivity.this, AnggotaPengaturanActivity.class));
                }
            }
        });

        btn_kirim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                subject = t_subject.getText().toString();
                saran = t_saran.getText().toString();
                if(subject.equals("") || saran.equals("")){
                    Toast.makeText(BuatSaranActivity.this, "Semua filed harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    SaranApi saranApi = Retro.saranRetro();
                    saranApi.addSaran(id_anggota, subject, saran).enqueue(new Callback<SaranModel>() {
                        @Override
                        public void onResponse(Call<SaranModel> call, Response<SaranModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1){
                                Toast.makeText(BuatSaranActivity.this, "Saran berhasil dikirimkan", Toast.LENGTH_SHORT).show();
                                t_saran.setText("");
                                t_subject.setText("");
                            }
                        }

                        @Override
                        public void onFailure(Call<SaranModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(BuatSaranActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
}
