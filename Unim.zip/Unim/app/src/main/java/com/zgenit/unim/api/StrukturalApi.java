package com.zgenit.unim.api;

import com.zgenit.unim.api.model.StrukturalModel;
import com.zgenit.unim.api.model.UserModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface StrukturalApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<UserModel> getOneRute();

    @FormUrlEncoded
    @POST("struktural/ajukan")
    Call<StrukturalModel> ajukan(
            @Field("id_anggota") String id_anggota,
            @Field("kd_ukm") String kd_ukm,
            @Field("jabatan") String jabatan,
            @Field("periode") String periode,
            @Field("visi") String visi
    );

    @FormUrlEncoded
    @POST("struktural/update")
    Call<StrukturalModel> update(
            @Field("id") int id,
            @Field("status") String status
    );

    @FormUrlEncoded
    @POST("struktural/add")
    Call<StrukturalModel> add(
            @Field("id") int id,
            @Field("user") String user,
            @Field("pass") String pass
    );

    @GET("struktural/index/{kd_ukm}/{status}")
    Call<ArrayList<StrukturalModel>> getPengajuan(@Path("kd_ukm") String kd_ukm, @Path("status") String status);
}

