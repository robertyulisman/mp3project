package com.zgenit.unim.pembina.ukm;

import android.annotation.SuppressLint;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.makeramen.roundedimageview.RoundedImageView;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.UriApi;
import com.zgenit.unim.api.model.UkmModel;
import com.zgenit.unim.struktural.ukm.StrukturalUkmActivity;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PembinaUkmActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.ukm)
    TextView ukm;
    @BindView(R.id.deskripsi)
    TextView deskripsi;
    @BindView(R.id.pembina)
    TextView pembina;
    @BindView(R.id.ketua)
    TextView ketua;
    @BindView(R.id.anggota)
    TextView anggota;
    @BindView(R.id.photo)
    RoundedImageView photo;
    String kd_ukm;
    
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembina_ukm);
        ButterKnife.bind(this);
        
        kd_ukm = getIntent().getStringExtra("kd_ukm");
        getDetail(kd_ukm);
        
        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaUkmActivity.this, MainActivity.class));
            }
        });
    }

    public void getDetail(String kd_ukm){
        final UkmApi ukmApi = Retro.ukmRetro();
        ukmApi.detailUkm(kd_ukm).enqueue(new Callback<UkmModel>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                if(response.body().getCode() == 1){
                    ukm.setText(response.body().getNama_ukm());
                    deskripsi.setText(response.body().getDeskripsi());;
                    pembina.setText(response.body().getPembina());
                    ketua.setText(response.body().getKetua());
                    anggota.setText(response.body().getJumlah()+" orang");
                    Glide.with(PembinaUkmActivity.this).load(UriApi.IMG_URL+"ukm/"+response.body().getPhoto())
                            .error(R.color.colorPhoto)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(photo);
                }else{
                    Toast.makeText(PembinaUkmActivity.this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UkmModel> call, Throwable t) {
                Toast.makeText(PembinaUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
