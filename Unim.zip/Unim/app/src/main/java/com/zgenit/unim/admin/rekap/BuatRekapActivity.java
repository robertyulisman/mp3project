package com.zgenit.unim.admin.rekap;

import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.admin.agenda.AddAgendaActivity;
import com.zgenit.unim.api.NilaiUkmApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.NilaiUkmModel;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class BuatRekapActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.ukm)
    Spinner t_ukm;
    @BindView(R.id.status)
    Spinner t_status;
    @BindView(R.id.nilai)
    Spinner t_nilai;
    @BindView(R.id.jml)
    AppCompatEditText t_jml;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    String ukm, status, nilai, jml;
    ProgressDialog progressDialog;
    List<String> ukms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_buat_rekap);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        ukms = new ArrayList<>();
        ukms.add("Pilih UKM");

        getUkm();

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, ukms);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        t_ukm.setAdapter(arrayAdapter);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(BuatRekapActivity.this, RekapNilaiUkmActivity.class));
            }
        });

        t_ukm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!t_ukm.getSelectedItem().toString().equals("Pilih UKM")){
                    final UkmApi ukmApi = Retro.ukmRetro();
                    String[] a_ukm = t_ukm.getSelectedItem().toString().split("-");
                    ukmApi.getAgenda(a_ukm[0].trim()).enqueue(new Callback<UkmModel>() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                            t_jml.setText(response.body().getCode().toString());
                        }

                        @Override
                        public void onFailure(Call<UkmModel> call, Throwable t) {
                            Toast.makeText(BuatRekapActivity.this, t.toString(), Toast.LENGTH_SHORT).show();
                            t_ukm.setSelection(0);
                        }
                    });
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s_ukm = t_ukm.getSelectedItem().toString();
                String[] a_ukm = s_ukm.split("-");
                ukm = a_ukm[0].trim();
                status = t_status.getSelectedItem().toString();
                nilai= t_nilai.getSelectedItem().toString();
                jml = Objects.requireNonNull(t_jml.getText()).toString();

                if(ukm.equals("Pilih UKM") || status.equals("Status") || nilai.equals("Nilai") || jml.equals("0") || jml.equals("")){
                    Toast.makeText(BuatRekapActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    final NilaiUkmApi nilaiUkmApi = Retro.nilaiUkmRetro();
                    nilaiUkmApi.addNilai(ukm, jml, status, nilai).enqueue(new Callback<NilaiUkmModel>() {
                        @Override
                        public void onResponse(Call<NilaiUkmModel> call, Response<NilaiUkmModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1 ){
                                Toast.makeText(BuatRekapActivity.this, "Data sukses ditambahkan", Toast.LENGTH_SHORT).show();
                                t_jml.setText("");
                                t_ukm.setSelection(0);
                                t_status.setSelection(0);
                                t_nilai.setSelection(0);
                            }else{
                                Toast.makeText(BuatRekapActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<NilaiUkmModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(BuatRekapActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private void getUkm(){
        final UkmApi ukmApi= Retro.ukmRetro();
        ukmApi.getUkm().enqueue(new Callback<ArrayList<UkmModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<UkmModel>> call, Response<ArrayList<UkmModel>> response) {
                if(!response.body().toString().equals("[]")){
                    for(int i = 0; i < response.body().toArray().length; i++){
                        ukms.add(response.body().get(i).getKd_ukm()+" - "+response.body().get(i).getNama_ukm());
                    }
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<UkmModel>> call, Throwable t) {
                Toast.makeText(BuatRekapActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
