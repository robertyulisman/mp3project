package com.zgenit.unim.admin.ukm;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.ActivityCompat;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.makeramen.roundedimageview.RoundedImageView;
import com.zgenit.unim.R;
import com.zgenit.unim.adapter.PembinaAdapter;
import com.zgenit.unim.admin.mahasiswa.DataMahasiswaActivity;
import com.zgenit.unim.admin.pembina.DataPembinaActivity;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.PembinaModel;
import com.zgenit.unim.api.model.UkmModel;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddUkmActivity extends AppCompatActivity {

    @BindView(R.id.nama)
    AppCompatEditText t_nama;
    @BindView(R.id.deskripsi)
    AppCompatEditText t_deskripsi;
    @BindView(R.id.pembina)
    Spinner t_pembina;
//    @BindView(R.id.struktural)
//    Spinner t_struktural;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.photo)
    RoundedImageView t_photo;
    Bitmap bitmap;
    String nama, deskripsi, photo;
    ProgressDialog progressDialog;
    List<String> pembinas;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_ukm);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddUkmActivity.this, InfoUkmActivity.class));
            }
        });

        pembinas = new ArrayList<>();
        pembinas.add("Pilih Pembina");

        getPembina();

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, pembinas);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        t_pembina.setAdapter(arrayAdapter);

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nama = Objects.requireNonNull(t_nama.getText()).toString();
                deskripsi = Objects.requireNonNull(t_deskripsi.getText()).toString();
                String s_pembina = t_pembina.getSelectedItem().toString();
                String[] pembina = s_pembina.split("-");

                if(nama.equals("") || s_pembina.equals("Pilih Pembina") || deskripsi.equals("")){
                    Toast.makeText(AddUkmActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    File imagefile = new File(photo);
                    final RequestBody requestBody = RequestBody.create(MediaType.parse("multipart/form-file"), imagefile);
                    RequestBody r_name = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(nama));
                    RequestBody r_description = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(deskripsi));
                    RequestBody r_pembina = RequestBody.create(MediaType.parse("text/plain"), String.valueOf(pembina[0].trim()));
                    MultipartBody.Part part = MultipartBody.Part.createFormData("photo", imagefile.getName(), requestBody);
                    final UkmApi ukmApi = Retro.ukmRetro();
                    ukmApi.addUkm(r_name, r_description, r_pembina, null, part).enqueue(new Callback<UkmModel>() {
                        @SuppressLint("NewApi")
                        @Override
                        public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1 ){
                                Toast.makeText(AddUkmActivity.this, "Data sukses ditambahkan", Toast.LENGTH_SHORT).show();
                                t_nama.setText("");
                                t_pembina.setSelection(0);
                                t_deskripsi.setText("");
                                t_photo.setImageDrawable(getDrawable(R.drawable.unggah));
//                                t_struktural.setSelection(0);
                            }else{
                                Toast.makeText(AddUkmActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<UkmModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(AddUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });

        t_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(ActivityCompat.checkSelfPermission(AddUkmActivity.this, Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED)
                {
                    ActivityCompat.requestPermissions(AddUkmActivity.this, new String[] {Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
                }
                else
                {
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, 200);
                }
            }
        });
    }

    private void getPembina(){
        final AnggotaApi anggotaApi = Retro.anggotaRetro();
        anggotaApi.getPembina().enqueue(new Callback<ArrayList<PembinaModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<PembinaModel>> call, Response<ArrayList<PembinaModel>> response) {
                if(!response.body().toString().equals("[]")){
                    for(int i = 0; i < response.body().toArray().length; i++){
                        pembinas.add(response.body().get(i).getId_pem()+" - "+response.body().get(i).getNama());
                    }
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<PembinaModel>> call, Throwable t) {
                Toast.makeText(AddUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK && requestCode == 200)
        {
            Cursor cursor = AddUkmActivity.this.getContentResolver().query(data.getData(), null,null,null,null);
            if(cursor==null)
            {
                photo = data.getData().getPath();
            }
            else
            {
                cursor.moveToFirst();
                int imgIndex = cursor.getColumnIndexOrThrow(MediaStore.Images.ImageColumns.DATA);
                photo = cursor.getString(imgIndex);
            }
            if(photo!=null)
            {
                File imageFile = new File(photo);
                bitmap =  BitmapFactory.decodeFile(imageFile.getAbsolutePath());

                int nh = (int) (bitmap.getHeight() * (512.0 / bitmap.getWidth()));
                bitmap = Bitmap.createScaledBitmap(bitmap, 512, nh, true);
                t_photo.setImageBitmap(bitmap);
            }
            else
            {
                Toast.makeText(AddUkmActivity.this, "Kesalahan Saat Mengambil File", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == 1)
        {
            if(grantResults.length > 0)
            {
                StringBuffer stringBuffer = new StringBuffer();
                int grantResult = grantResults[0];
                if(grantResult==PackageManager.PERMISSION_GRANTED)
                {
                    Intent intent = new Intent(Intent.ACTION_PICK);
                    intent.setType("image/*");
                    startActivityForResult(intent, 200);
                }
            }
        }
    }
}
