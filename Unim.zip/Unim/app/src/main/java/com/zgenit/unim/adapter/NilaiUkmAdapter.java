package com.zgenit.unim.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.zgenit.unim.R;
import com.zgenit.unim.agenda.AgendaDetailActivity;
import com.zgenit.unim.api.model.NilaiUkmModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class NilaiUkmAdapter extends RecyclerView.Adapter<NilaiUkmAdapter.MyViewHolder> {

    private Context context;
    private List<NilaiUkmModel> NilaiUkmModels;

    public NilaiUkmAdapter(Context context, ArrayList<NilaiUkmModel> NilaiUkmModels) {
        this.context = context;
        this.NilaiUkmModels = NilaiUkmModels;
    }

    @NonNull
    @Override
    public NilaiUkmAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.nilai_ukm_list,
                viewGroup, false);
        return new NilaiUkmAdapter.MyViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final NilaiUkmAdapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.ukm.setText(NilaiUkmModels.get(i).getUkm());
        myViewHolder.jml.setText(NilaiUkmModels.get(i).getJml_keg()+" kegiatan");
        myViewHolder.status.setText(NilaiUkmModels.get(i).getStatus());
        myViewHolder.nilai.setText(NilaiUkmModels.get(i).getNilai());
    }

    @Override
    public int getItemCount() {
        return NilaiUkmModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.nilaiUkm)
        LinearLayout nilaiUkm;
        @BindView(R.id.ukm)
        TextView ukm;
        @BindView(R.id.jml)
        TextView jml;
        @BindView(R.id.status)
        TextView status;
        @BindView(R.id.nilai)
        TextView nilai;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}