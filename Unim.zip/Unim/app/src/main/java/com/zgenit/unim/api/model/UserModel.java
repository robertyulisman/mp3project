package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UserModel {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("id_anggota")
    @Expose
    private String id_anggota;
    @SerializedName("user")
    @Expose
    private String user;
    @SerializedName("pass")
    @Expose
    private String pass;
    @SerializedName("nim")
    @Expose
    private String nim;
    @SerializedName("nama")
    @Expose
    private String nama;
    @SerializedName("no_telp")
    @Expose
    private String no_telp;
    @SerializedName("fakultas")
    @Expose
    private String fakultas;
    @SerializedName("prodi")
    @Expose
    private String prodi;
    @SerializedName("code")
    @Expose
    private Integer code;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("kd_ukm")
    @Expose
    private String kd_ukm;
    @SerializedName("alamat")
    @Expose
    private String alamat;
    @SerializedName("jabatan")
    @Expose
    private String jabatan;
    @SerializedName("periode")
    @Expose
    private String periode;
    @SerializedName("photo")
    @Expose
    private String photo;
    @SerializedName("j_kel")
    @Expose
    private String jkel;
    @SerializedName("ttl")
    @Expose
    private String ttl;

    public String getId() { return id; }
    public String getId_anggota() { return id_anggota; }
    public String getUser() { return user; }
    public String getPass() { return pass; }
    public String getNama() { return nama; }
    public String getNo_telp() { return no_telp; }
    public String getFakultas() { return fakultas; }
    public String getProdi() { return prodi; }
    public Integer getCode() { return code; }
    public String getMessage() { return message; }
    public String getKd_ukm() { return kd_ukm; }
    public String getNim() { return nim; }
    public String getAlamat() { return alamat; }
    public String getJabatan() { return jabatan; }
    public String getPeriode() { return periode; }
    public String getPhoto() { return photo; }
    public String getJkel() { return jkel; }
    public String getTtl() { return ttl; }
}
