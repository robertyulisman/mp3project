package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PembinaModel {
        @SerializedName("id_pem")
        @Expose
        private String id_pem;
        @SerializedName("pass")
        @Expose
        private String pass;
        @SerializedName("nama")
        @Expose
        private String nama;
        @SerializedName("user")
        @Expose
        private String user;
        @SerializedName("no_telp")
        @Expose
        private String no_telp;
        @SerializedName("code")
        @Expose
        private Integer code;
        @SerializedName("message")
        @Expose
        private String message;
        @SerializedName("photo")
        @Expose
        private String photo;

        public String getId_pem() { return id_pem; }
        public String getPass() { return pass; }
        public String getNama() { return nama; }
        public String getUser() { return user; }
        public String getNo_telp() { return no_telp; }
        public Integer getCode() { return code; }
        public String getMessage() { return message; }
        public String getPhoto() { return photo; }
}
