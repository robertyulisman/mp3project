package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class AgendaModel {
    @SerializedName("id")
    @Expose
    private String id;
    @SerializedName("kd_agenda")
    @Expose
    private String kd_agenda;
    @SerializedName("kd_ukm")
    @Expose
    private String kd_ukm;
    @SerializedName("ukm")
    @Expose
    private String ukm;
    @SerializedName("nama_keg")
    @Expose
    private String nama_keg;
    @SerializedName("jns_keg")
    @Expose
    private String jns_keg;
    @SerializedName("tgl_keg")
    @Expose
    private String tgl_keg;
    @SerializedName("jam")
    @Expose
    private String jam;
    @SerializedName("tempat")
    @Expose
    private String tempat;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("nama_ukm")
    @Expose
    private String nama_ukm;
    @SerializedName("code")
    @Expose
    private Integer code;
    @SerializedName("message")
    @Expose
    private String message;
    @SerializedName("id_struk")
    @Expose
    private String id_struk;
    @SerializedName("jabatan")
    @Expose
    private String jabatan;
    @SerializedName("nama")
    @Expose
    private String nama;

    public String getKd_agenda() { return kd_agenda; }
    public String getKd_ukm() { return kd_ukm; }
    public String getUkm() { return ukm; }
    public String getStatus() { return status; }
    public String getNama_ukm() { return nama_ukm; }
    public String getNama_keg() { return nama_keg; }
    public String getJns_keg() { return jns_keg; }
    public String getTgl_keg() { return tgl_keg; }
    public String getJam() { return jam; }
    public String getTempat() { return tempat; }
    public Integer getCode() { return code; }
    public String getMessage() { return message; }
    public String getId_struk() { return id_struk; }
    public String getJabatan() { return jabatan; }
    public String getNama() { return nama; }
    public String getId() { return id; }
}
