package com.zgenit.unim.api;

import com.zgenit.unim.api.model.AgendaModel;
import com.zgenit.unim.api.model.SaranModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface SaranApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<AgendaModel> getOneRute();

    @GET("saran/index")
    Call<ArrayList<SaranModel>> getSaran();

    @GET("saran/get/{id_saran}")
    Call<SaranModel> oneSaran(@Path("id_saran") int id_saran);

    @FormUrlEncoded
    @POST("saran/add")
    Call<SaranModel> addSaran(
            @Field("pengirim") String pengirim,
            @Field("subject") String subject,
            @Field("pesan") String pesan
    );

    @FormUrlEncoded
    @POST("saran/delete")
    Call<SaranModel> deleteSaran(
            @Field("id_saran") int id_saran
    );
}

