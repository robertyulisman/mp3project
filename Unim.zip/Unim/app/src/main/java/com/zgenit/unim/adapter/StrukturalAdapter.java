package com.zgenit.unim.adapter;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.support.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.AuthActivity;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.admin.mahasiswa.EditMahasiswaActivity;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.StrukturalApi;
import com.zgenit.unim.api.model.StrukturalModel;
import com.zgenit.unim.pembina.konfirmasi.AkunStrukturalActivity;
import com.zgenit.unim.pembina.konfirmasi.PembinaStrukturalActivity;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StrukturalAdapter extends RecyclerView.Adapter<StrukturalAdapter.MyViewHolder> {

    private Context context;
    private List<StrukturalModel> StrukturalModels;
    ProgressDialog progressDialog;

    public StrukturalAdapter(Context context, ArrayList<StrukturalModel> StrukturalModels) {
        this.context = context;
        this.StrukturalModels = StrukturalModels;
    }

    @NonNull
    @Override
    public StrukturalAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.struktural_list,
                viewGroup, false);
        return new StrukturalAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final StrukturalAdapter.MyViewHolder myViewHolder, final int i) {
        if(StrukturalModels.get(i).getStatus().equals("Diterima")){
            myViewHolder.periode.setVisibility(View.VISIBLE);
            myViewHolder.visi.setVisibility(View.GONE);
            myViewHolder.periode.setText(StrukturalModels.get(i).getPeriode());
        }
        myViewHolder.nama.setText(StrukturalModels.get(i).getNama());
        myViewHolder.jabatan.setText(StrukturalModels.get(i).getJabatan());
        myViewHolder.visi.setText(StrukturalModels.get(i).getVisi());
        myViewHolder.konfirmasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), AkunStrukturalActivity.class);
                intent.putExtra("id", StrukturalModels.get(i).getId());
                v.getContext().startActivity(intent);
            }
        });
        if(StrukturalModels.get(i).getStatus().equals("Meminta")){
            myViewHolder.btn.setVisibility(View.VISIBLE);
        }
        progressDialog = new ProgressDialog(myViewHolder.itemView.getContext());
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);
        myViewHolder.tolak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setTitle("Konfirmasi Tolak");
                builder.setMessage("Yakin ingin menolak pengajuan ini ?");
                builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialogInterface, int id) {
                        progressDialog.show();
                        StrukturalApi strukturalApi = Retro.strukturalRetro();
                        strukturalApi.update(StrukturalModels.get(i).getId(), "Ditolak").enqueue(new Callback<StrukturalModel>() {
                            @Override
                            public void onResponse(Call<StrukturalModel> call, Response<StrukturalModel> response) {
                                if(response.body().getCode() == 1){
                                    progressDialog.dismiss();
                                    Toast.makeText(v.getContext(), "Pengajuan Struktural Telah Ditolak", Toast.LENGTH_SHORT).show();
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            v.getContext().startActivity(new Intent(v.getContext(), PembinaStrukturalActivity.class));
                                        }
                                    },1000);
                                }
                            }

                            @Override
                            public void onFailure(Call<StrukturalModel> call, Throwable t) {
                                progressDialog.dismiss();
                                Toast.makeText(v.getContext(), "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return StrukturalModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.struktural)
        LinearLayout struktural;
        @BindView(R.id.nama)
        TextView nama;
        @BindView(R.id.jabatan)
        TextView jabatan;
        @BindView(R.id.visi)
        TextView visi;
        @BindView(R.id.periode)
        TextView periode;
        @BindView(R.id.konfirmasi)
        TextView konfirmasi;
        @BindView(R.id.tolak)
        TextView tolak;
        @BindView(R.id.btn)
        LinearLayout btn;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}
