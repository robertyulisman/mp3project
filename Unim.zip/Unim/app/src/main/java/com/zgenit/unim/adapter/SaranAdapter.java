package com.zgenit.unim.adapter;

import android.content.Context;
import android.content.Intent;
import android.support.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.admin.saran.DetailSaranActivity;
import com.zgenit.unim.admin.saran.SaranMaukActivity;
import com.zgenit.unim.agenda.AgendaDetailActivity;
import com.zgenit.unim.api.model.SaranModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;

public class SaranAdapter extends RecyclerView.Adapter<SaranAdapter.MyViewHolder> {

    private Context context;
    private List<SaranModel> SaranModels;

    public SaranAdapter(Context context, ArrayList<SaranModel> SaranModels) {
        this.context = context;
        this.SaranModels = SaranModels;
    }

    @NonNull
    @Override
    public SaranAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.saran_list,
                viewGroup, false);
        return new SaranAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final SaranAdapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.subjek.setText(SaranModels.get(i).getSubject());
        myViewHolder.pesan.setText(SaranModels.get(i).getPesan());
        myViewHolder.pengirim.setText(SaranModels.get(i).getNama());
        myViewHolder.saran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), DetailSaranActivity.class);
                intent.putExtra("id_saran", SaranModels.get(i).getId_saran());
                v.getContext().startActivity(intent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return SaranModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.saran)
        LinearLayout saran;
        @BindView(R.id.subjek)
        TextView subjek;
        @BindView(R.id.pengirim)
        TextView pengirim;
        @BindView(R.id.pesan)
        TextView pesan;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}