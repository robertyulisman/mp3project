package com.zgenit.unim.api;

import com.zgenit.unim.api.model.UkmModel;
import com.zgenit.unim.api.model.UserModel;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface UserApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<UserModel> getOneRute();

    @GET("user/anggota/{id_anggota}")
    Call<UserModel> detailAnggota(@Path("id_anggota") String id_anggota);

    @FormUrlEncoded
    @POST("user/anggota")
    Call<UserModel> profileAnggota(
            @Field("id_anggota") String id_anggota,
            @Field("nama") String nama,
            @Field("no_telp") String no_telp,
            @Field("fakultas") String fakultas,
            @Field("prodi") String prodi
    );

    @FormUrlEncoded
    @POST("user/pembina")
    Call<UserModel> profilePembina(
            @Field("id_pem") String id_pem,
            @Field("nama") String nama,
            @Field("no_telp") String no_telp
    );

    @FormUrlEncoded
    @POST("user/password")
    Call<UserModel> updatePassword(
            @Field("id") String id,
            @Field("old_pass") String old_pass,
            @Field("new_pass") String new_pass,
            @Field("role") String role
    );

    @GET("user/cetak/{id}")
    Call<UserModel> cetakUser(@Path("id") String id);

    @Multipart
    @POST("user/photo")
    Call<UkmModel> editPhoto(
            @Part("id") RequestBody id,
            @Part("role") RequestBody role,
            @Part MultipartBody.Part photo
    );
}

