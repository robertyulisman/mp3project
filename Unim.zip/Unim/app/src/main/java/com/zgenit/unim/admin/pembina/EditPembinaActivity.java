package com.zgenit.unim.admin.pembina;

import android.app.ProgressDialog;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.PembinaModel;

import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class EditPembinaActivity extends AppCompatActivity {

    @BindView(R.id.id_pem)
    AppCompatEditText t_idpem;
    @BindView(R.id.nama)
    AppCompatEditText t_nama;
    @BindView(R.id.user)
    AppCompatEditText t_user;
    @BindView(R.id.pass)
    AppCompatEditText t_pass;
    @BindView(R.id.no_telp)
    AppCompatEditText t_notelp;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String nama, user, pass, no_telp, id_pem;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_pembina);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        id_pem = getIntent().getStringExtra("id_pem");
        getPembina(id_pem);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(EditPembinaActivity.this, DataPembinaActivity.class));
            }
        });
        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                user = Objects.requireNonNull(t_user.getText()).toString();
                nama = Objects.requireNonNull(t_nama.getText()).toString();
                pass = Objects.requireNonNull(t_pass.getText()).toString();
                no_telp = Objects.requireNonNull(t_notelp.getText()).toString();

                if(user.equals("") || nama.equals("") || pass.equals("") || no_telp.equals("") || id_pem.equals("")){
                    Toast.makeText(EditPembinaActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                }else {
                    progressDialog.show();
                    final AnggotaApi anggotaApi = Retro.anggotaRetro();
                    anggotaApi.editPembina(id_pem, nama, user, pass, no_telp).enqueue(new Callback<PembinaModel>() {
                        @Override
                        public void onResponse(Call<PembinaModel> call, Response<PembinaModel> response) {
                            progressDialog.dismiss();
                            if (response.body().getCode() == 1) {
                                Toast.makeText(EditPembinaActivity.this, "Data sukses diedit", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(EditPembinaActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<PembinaModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(EditPembinaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }
    private void getPembina(String nim){
        final AnggotaApi anggotaApi = Retro.anggotaRetro();
        anggotaApi.onePembina(nim).enqueue(new Callback<PembinaModel>() {
            @Override
            public void onResponse(Call<PembinaModel> call, Response<PembinaModel> response) {
                if(response.body().toString().equals("0")){
                    Toast.makeText(EditPembinaActivity.this, "Data Tidak Ditemukan", Toast.LENGTH_SHORT).show();
                }else{
                    t_user.setText(response.body().getUser());
                    t_nama.setText(response.body().getNama());
                    t_pass.setText(response.body().getPass());
                    t_notelp.setText(response.body().getNo_telp());
                    t_idpem.setText(response.body().getId_pem());
                }
            }

            @Override
            public void onFailure(Call<PembinaModel> call, Throwable t) {

            }
        });
    }
}
