package com.zgenit.unim.anggota.cetak;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;
import com.makeramen.roundedimageview.RoundedImageView;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UriApi;
import com.zgenit.unim.api.UserApi;
import com.zgenit.unim.api.model.UserModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AnggotaCetakActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.nim)
    TextView nim;
    @BindView(R.id.nama)
    TextView nama;
    @BindView(R.id.telp)
    TextView telp;
    @BindView(R.id.alamat)
    TextView alamat;
    @BindView(R.id.jkel)
    TextView jkel;
    @BindView(R.id.ttl)
    TextView ttl;
    @BindView(R.id.qrcode)
    ImageView qrcode;
    @BindView(R.id.photo)
    RoundedImageView photo;
    String id_anggota, code,role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anggota_cetak);
        ButterKnife.bind(this);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        id_anggota = sharedPreferences.getString("id", "");
        role = sharedPreferences.getString("role", "");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                    startActivity(new Intent(AnggotaCetakActivity.this, MainActivity.class));
            }
        });
        getDetail(id_anggota);
    }

    public void getDetail(String id_anggota){
        final UserApi userApi = Retro.userRetro();
        userApi.cetakUser(id_anggota).enqueue(new Callback<UserModel>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<UserModel> call, Response<UserModel> response) {
                if(response.body().getCode() == 1){
                    nim.setText(response.body().getNim());
                    nama.setText(response.body().getNama());
                    telp.setText(response.body().getNo_telp());
                    alamat.setText(response.body().getAlamat());
                    code = response.body().getNim()+"<><>"+response.body().getPass()+"<><>"+role;
                    if(response.body().getJkel().equals("L")){
                        jkel.setText("Laki-Laki");
                    }else if(response.body().getJkel().equals("P")) {
                        jkel.setText("Perempuan");
                    }
                    ttl.setText(response.body().getTtl());
                    Glide.with(AnggotaCetakActivity.this)
                            .load(UriApi.IMG_URL+"mahasiswa/"+response.body().getPhoto())
                            .error(R.color.colorPhoto)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(photo);
                    MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
                    try{
                        BitMatrix bitMatrix = multiFormatWriter.encode(code, BarcodeFormat.QR_CODE,300,300);
                        BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
                        Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
                        qrcode.setImageBitmap(bitmap);
                    }catch(WriterException e){
                        System.out.println(e.getMessage());
                    }
                }else{
                    Toast.makeText(AnggotaCetakActivity.this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UserModel> call, Throwable t) {
                Toast.makeText(AnggotaCetakActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
