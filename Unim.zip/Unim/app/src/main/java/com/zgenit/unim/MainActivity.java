package com.zgenit.unim;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.support.v7.widget.CardView;
import android.view.View;
import android.widget.ImageView;
import android.widget.ScrollView;
import android.widget.TextView;

import com.zgenit.unim.admin.InfoAnggotaActivity;
import com.zgenit.unim.admin.agenda.AgendaKegiatanActivity;
import com.zgenit.unim.admin.elektabilitas.ElektabilitasUkmActivity;
import com.zgenit.unim.admin.rekap.DaftarRekapActivity;
import com.zgenit.unim.admin.rekap.RekapNilaiUkmActivity;
import com.zgenit.unim.admin.saran.SaranMaukActivity;
import com.zgenit.unim.admin.ukm.InfoUkmActivity;
import com.zgenit.unim.anggota.agenda.AnggotaAgendaActivity;
import com.zgenit.unim.anggota.cetak.AnggotaCetakActivity;
import com.zgenit.unim.anggota.pengaturan.AnggotaPengaturanActivity;
import com.zgenit.unim.anggota.rekap.RekapAktifActivity;
import com.zgenit.unim.anggota.struktur.AnggotaStrukturActivity;
import com.zgenit.unim.anggota.struktur.DetailUkmActivity;
import com.zgenit.unim.anggota.struktural.AjukanStrukturalActivity;
import com.zgenit.unim.anggota.ukm.AnggotaUkmActivity;
import com.zgenit.unim.pembina.agenda.PembinaAgendaActivity;
import com.zgenit.unim.pembina.elektabilitas.PembinaElektabilitasActivity;
import com.zgenit.unim.pembina.konfirmasi.PembinaKonfirmasiActivity;
import com.zgenit.unim.pembina.pengaturan.PembinaPengaturanActivity;
import com.zgenit.unim.pembina.ukm.PembinaUkmActivity;
import com.zgenit.unim.struktural.agenda.SAddAgendaActivity;
import com.zgenit.unim.struktural.agenda.StrukturalAgendaActivity;
import com.zgenit.unim.struktural.cetak.StrukturalCetakActivity;
import com.zgenit.unim.struktural.pengaturan.StrukturalPengaturanActivity;
import com.zgenit.unim.struktural.ukm.StrukturalUkmActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class MainActivity extends AppCompatActivity {

    @BindView(R.id.log_as)
    TextView log_as;
    String role = "-";
    @BindView(R.id.info_anggota)
    CardView info_anggota;
    @BindView(R.id.info_ukm)
    CardView info_ukm;
    @BindView(R.id.agenda)
    CardView agenda;
    @BindView(R.id.rekapitulasi)
    CardView rekapitulasi;
    @BindView(R.id.elektabilitas)
    CardView elektabilitas;
    @BindView(R.id.saran)
    CardView saran;
    @BindView(R.id.backup)
    CardView backup;
    @BindView(R.id.btn_logout)
    ImageView btn_logout;
    @BindView(R.id.admin)
    ScrollView admin;
    @BindView(R.id.anggota)
    ScrollView anggota;
    @BindView(R.id.a_agenda)
    CardView a_agenda;
    @BindView(R.id.a_cetak)
    CardView a_cetak;
    @BindView(R.id.a_pengaturan)
    CardView a_pengaturan;
    @BindView(R.id.a_rekapitulasi)
    CardView a_rekapitulasi;
    @BindView(R.id.a_struktur)
    CardView a_struktur;
    @BindView(R.id.a_struktural)
    CardView a_struktural;
    @BindView(R.id.a_ukm)
    CardView a_ukm;
    @BindView(R.id.pembina)
    ScrollView pembina;
    @BindView(R.id.p_anggota)
    CardView p_anggota;
    @BindView(R.id.p_ukm)
    CardView p_ukm;
    @BindView(R.id.p_agenda)
    CardView p_agenda;
    @BindView(R.id.p_rekap)
    CardView p_rekap;
    @BindView(R.id.p_elektabilitas)
    CardView p_elektabilitas;
    @BindView(R.id.p_kegiatan)
    CardView p_kegiatan;
    @BindView(R.id.p_atur)
    CardView p_atur;
    @BindView(R.id.struktural)
    ScrollView struktural;
    @BindView(R.id.s_agenda)
    CardView s_agenda;
    @BindView(R.id.s_tambah)
    CardView s_tambah;
    @BindView(R.id.s_ukm)
    CardView s_ukm;
    @BindView(R.id.s_rekap)
    CardView s_rekap;
    @BindView(R.id.s_struktur)
    CardView s_struktur;
    @BindView(R.id.s_cetak)
    CardView s_cetak;
    @BindView(R.id.s_atur)
    CardView s_atur;
    String kd_ukm;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ButterKnife.bind(this);

        final SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        role = sharedPreferences.getString("role", "-");
        kd_ukm = sharedPreferences.getString("kd_ukm", "");
        log_as.setText("Anda Login Sebagai "+role);

        switch (role) {
            case "Admin":
                admin.setVisibility(View.VISIBLE);
                break;
            case "Anggota":
                anggota.setVisibility(View.VISIBLE);
                break;
            case "Pembina":
                pembina.setVisibility(View.VISIBLE);
                break;
            case "Struktural":
                struktural.setVisibility(View.VISIBLE);
                break;
        }

        info_anggota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, InfoAnggotaActivity.class));
            }
        });
        info_ukm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, InfoUkmActivity.class));
            }
        });
        agenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AgendaKegiatanActivity.class));
            }
        });
        rekapitulasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RekapNilaiUkmActivity.class));
            }
        });
        elektabilitas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, ElektabilitasUkmActivity.class));
            }
        });
        saran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SaranMaukActivity.class));
            }
        });
        backup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent browserIntent = new Intent(Intent.ACTION_VIEW, Uri.parse("http://192.168.43.20/projek/unim/data/backup"));
                startActivity(browserIntent);
            }
        });
        a_agenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AnggotaAgendaActivity.class));
            }
        });
        a_ukm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AnggotaUkmActivity.class));
            }
        });
        a_pengaturan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AnggotaPengaturanActivity.class));
            }
        });
        a_struktur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AnggotaStrukturActivity.class));
            }
        });
        a_struktural.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AjukanStrukturalActivity.class));
            }
        });
        a_rekapitulasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, RekapAktifActivity.class));
            }
        });
        a_cetak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, AnggotaCetakActivity.class));
            }
        });
        p_anggota.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DetailUkmActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(intent);
            }
        });
        p_ukm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PembinaUkmActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(intent);
            }
        });
        p_agenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PembinaAgendaActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(intent);
            }
        });
        p_rekap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DaftarRekapActivity.class));
            }
        });
        p_elektabilitas.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, PembinaElektabilitasActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(intent);
            }
        });
        p_atur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PembinaPengaturanActivity.class));
            }
        });
        p_kegiatan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, PembinaKonfirmasiActivity.class));
            }
        });
        s_agenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, StrukturalAgendaActivity.class));
            }
        });
        s_tambah.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SAddAgendaActivity.class));
            }
        });
        s_ukm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, StrukturalUkmActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(intent);
            }
        });
        s_rekap.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, DaftarRekapActivity.class));
            }
        });
        s_struktur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, DetailUkmActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(intent);
            }
        });
        s_atur.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, StrukturalPengaturanActivity.class));
            }
        });
        s_cetak.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, StrukturalCetakActivity.class));
            }
        });
        btn_logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(MainActivity.this);
                builder.setTitle("Konfirmasi Logout");
                builder.setMessage("Yakin ingin Logout ?");
                builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialogInterface, int id) {
                        SharedPreferences spref = getSharedPreferences("Unim", MODE_PRIVATE);
                        SharedPreferences.Editor editor = spref.edit();
                        editor.clear();
                        editor.apply();
                        Intent i = new Intent(MainActivity.this, AuthActivity.class);
                        startActivity(i);
                    }
                });
                builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });
    }
}
