package com.zgenit.unim.adapter;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentStatePagerAdapter;

import com.zgenit.unim.fragment.AgendaFragment;
import com.zgenit.unim.fragment.LoginFragment;
import com.zgenit.unim.fragment.RegisterFragment;

public class PageAdapter extends FragmentStatePagerAdapter {

    private int tabNumber;

    public PageAdapter(FragmentManager fm, int numOfTab)
    {
        super(fm);
        this.tabNumber = numOfTab;
    }

    @Override
    public Fragment getItem(int i) {
        switch (i)
        {
            case 0:
                return new RegisterFragment();
            case 1:
                return new LoginFragment();
            case 2:
                return new AgendaFragment();
            default:
                return null;
        }
    }

    @Override
    public int getCount() {
        return tabNumber;
    }

}
