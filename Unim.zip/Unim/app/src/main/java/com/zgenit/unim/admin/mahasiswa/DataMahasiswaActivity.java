package com.zgenit.unim.admin.mahasiswa;

import android.annotation.SuppressLint;
import android.content.Intent;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.adapter.MahasiswaAdapter;
import com.zgenit.unim.admin.InfoAnggotaActivity;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.MahasiswaModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DataMahasiswaActivity extends AppCompatActivity {

    @BindView(R.id.rv_anggota)
    RecyclerView rv_anggota;
    @BindView(R.id.fab_add)
    FloatingActionButton fab_add;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.search)
    EditText search;
    @BindView(R.id.search2)
    Spinner search2;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    ArrayList<MahasiswaModel> mahasiswaModelArrayList, mahasiswaFilters, mahasiswaAll;
    MahasiswaAdapter mahasiswaAdapter;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_mahasiswa);
        ButterKnife.bind(this);

        message.setText("Sedang Memproses...");

        getMahasiswa();

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DataMahasiswaActivity.this, InfoAnggotaActivity.class));
            }
        });

        fab_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DataMahasiswaActivity.this, AddMahasiswaActivity.class));
            }
        });
    }

    private void getMahasiswa(){
        final AnggotaApi anggotaApi = Retro.anggotaRetro();
        anggotaApi.getMahasiswa().enqueue(new Callback<ArrayList<MahasiswaModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<MahasiswaModel>> call, Response<ArrayList<MahasiswaModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    mahasiswaModelArrayList = new ArrayList<>();
                    mahasiswaAll = new ArrayList<>();
                    mahasiswaModelArrayList = response.body();
                    mahasiswaAll = mahasiswaModelArrayList;
                    mahasiswaAdapter = new MahasiswaAdapter(DataMahasiswaActivity.this, mahasiswaModelArrayList);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(DataMahasiswaActivity.this);
                    rv_anggota.setLayoutManager(layoutManager);
                    rv_anggota.setAdapter(mahasiswaAdapter);
                }
                searchFunction();
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<MahasiswaModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(DataMahasiswaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                searchFunction();
            }
        });
    }

    public void searchData(String text, String filter)
    {
        mahasiswaFilters = new ArrayList<>();
        for(MahasiswaModel mahasiswaModel : mahasiswaAll){
            if(filter.equals("Nama")){
                if(mahasiswaModel.getNama().toLowerCase().contains(text.toLowerCase())){
                    mahasiswaFilters.add(mahasiswaModel);
                }
            }else if(filter.equals("Nim")){
                if(mahasiswaModel.getNim().toLowerCase().contains(text.toLowerCase())){
                    mahasiswaFilters.add(mahasiswaModel);
                }
            }
        }
        mahasiswaModelArrayList = mahasiswaFilters;
        mahasiswaAdapter.filterList(mahasiswaFilters);
        mahasiswaAdapter.notifyDataSetChanged();
    }

    public void searchFunction(){
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchData(s.toString(), search2.getSelectedItem().toString());
            }
        });

        search2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                searchData(search.getText().toString(), search2.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
