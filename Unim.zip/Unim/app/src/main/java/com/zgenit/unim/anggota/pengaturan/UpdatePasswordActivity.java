package com.zgenit.unim.anggota.pengaturan;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UserApi;
import com.zgenit.unim.api.model.UserModel;
import com.zgenit.unim.pembina.pengaturan.PembinaPengaturanActivity;
import com.zgenit.unim.struktural.pengaturan.StrukturalPengaturanActivity;
import com.zgenit.unim.struktural.ukm.StrukturalUkmActivity;

import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UpdatePasswordActivity extends AppCompatActivity {

    @BindView(R.id.old_pass)
    AppCompatEditText old_pass;
    @BindView(R.id.new_pass)
    AppCompatEditText new_pass;
    @BindView(R.id.conf_pass)
    AppCompatEditText conf_pass;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    ProgressDialog progressDialog;
    String id_anggota, role;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_password);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        id_anggota = sharedPreferences.getString("id", "");
        role = sharedPreferences.getString("role", "");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(role.equals("Pembina")){
                    startActivity(new Intent(UpdatePasswordActivity.this, PembinaPengaturanActivity.class));
                }else if(role.equals("Struktural")){
                    startActivity(new Intent(UpdatePasswordActivity.this, StrukturalPengaturanActivity.class));
                }else {
                    startActivity(new Intent(UpdatePasswordActivity.this, AnggotaPengaturanActivity.class));
                }
            }
        });

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String s_old_pass = Objects.requireNonNull(old_pass.getText()).toString();
                String s_new_pass = Objects.requireNonNull(new_pass.getText()).toString();
                String s_conf_pass = Objects.requireNonNull(conf_pass.getText()).toString();
                if(s_old_pass.equals("") || s_new_pass.equals("") || s_conf_pass.equals("")){
                    Toast.makeText(UpdatePasswordActivity.this, "Semua filed harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    if(!s_new_pass.equals(s_conf_pass)){
                        Toast.makeText(UpdatePasswordActivity.this, "Password tidak sama", Toast.LENGTH_SHORT).show();
                    }else {
                        progressDialog.show();
                        UserApi saranApi = Retro.userRetro();
                        saranApi.updatePassword(id_anggota, s_old_pass, s_new_pass, role).enqueue(new Callback<UserModel>() {
                            @Override
                            public void onResponse(Call<UserModel> call, Response<UserModel> response) {
                                progressDialog.dismiss();
                                if (response.body().getCode() == 1) {
                                    Toast.makeText(UpdatePasswordActivity.this, "Password Berhasil Diubah", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(UpdatePasswordActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<UserModel> call, Throwable t) {
                                progressDialog.dismiss();
                                Toast.makeText(UpdatePasswordActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                }
            }
        });
    }
}
