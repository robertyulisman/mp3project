package com.zgenit.unim.api;

import com.zgenit.unim.api.model.MahasiswaModel;
import com.zgenit.unim.api.model.PembinaModel;
import com.zgenit.unim.api.model.UserModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface AnggotaApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<MahasiswaModel> getOneRute();

    @GET("mahasiswa/index")
    Call<ArrayList<MahasiswaModel>> getMahasiswa();

    @GET("mahasiswa/get/{nim}")
    Call<MahasiswaModel> oneMahasiswa(@Path("nim") String nim);

    @FormUrlEncoded
    @POST("mahasiswa/add")
    Call<MahasiswaModel> addMahasiswa(
            @Field("nim") String nim,
            @Field("nama") String nama,
            @Field("pass") String pass,
            @Field("alamat") String alamat,
            @Field("j_kel") String j_kel,
            @Field("ttl") String ttl
    );

    @FormUrlEncoded
    @POST("mahasiswa/edit")
    Call<MahasiswaModel> editMahasiswa(
            @Field("nim") String nim,
            @Field("nama") String nama,
            @Field("pass") String pass,
            @Field("alamat") String alamat,
            @Field("j_kel") String j_kel,
            @Field("ttl") String ttl
    );

    @FormUrlEncoded
    @POST("mahasiswa/delete")
    Call<MahasiswaModel> deleteMahasiswa(
            @Field("nim") String nim
    );

    @GET("pembina/index")
    Call<ArrayList<PembinaModel>> getPembina();

    @GET("pembina/get/{id_pem}")
    Call<PembinaModel> onePembina(@Path("id_pem") String id_pem);

    @FormUrlEncoded
    @POST("pembina/add")
    Call<PembinaModel> addPembina(
            @Field("nama") String nama,
            @Field("user") String user,
            @Field("pass") String pass,
            @Field("no_telp") String no_telp
    );

    @FormUrlEncoded
    @POST("pembina/edit")
    Call<PembinaModel> editPembina(
            @Field("id_pem") String id_pem,
            @Field("nama") String nama,
            @Field("user") String user,
            @Field("pass") String pass,
            @Field("no_telp") String no_telp
    );

    @FormUrlEncoded
    @POST("pembina/delete")
    Call<PembinaModel> deletePembina(
            @Field("id_pem") String id_pem
    );
}

