package com.zgenit.unim.admin.elektabilitas;

import android.annotation.SuppressLint;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.interfaces.datasets.IBarDataSet;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.admin.agenda.AddAgendaActivity;
import com.zgenit.unim.admin.rekap.BuatRekapActivity;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ElektabilitasUkmActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.ukm)
    Spinner t_ukm;
    @BindView(R.id.barchart)
    BarChart barchart;
    List<String> ukms;
    List<BarEntry> entries = new ArrayList<>();
    ArrayList<String> months;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_elektabilitas_ukm);
        ButterKnife.bind(this);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(ElektabilitasUkmActivity.this, MainActivity.class));
            }
        });

        ukms = new ArrayList<>();
        ukms.add("Pilih UKM");

        getUkm();

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, ukms);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        t_ukm.setAdapter(arrayAdapter);

        months = new ArrayList<String>();

        months.add("Jan");
        months.add("Feb");
        months.add("Mar");
        months.add("Apr");
        months.add("Mei");
        months.add("Jun");
        months.add("Jul");
        months.add("Agu");
        months.add("Sep");
        months.add("Okt");
        months.add("Nov");
        months.add("Des");

        t_ukm.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if(!t_ukm.getSelectedItem().toString().equals("Pilih UKM")) {
                    String s_ukm = t_ukm.getSelectedItem().toString();
                    String[] a_ukm = s_ukm.split("-");
                    final UkmApi ukmApi = Retro.ukmRetro();
                    ukmApi.getRekap(a_ukm[0].trim()).enqueue(new Callback<UkmModel>() {
                        @SuppressLint("SetTextI18n")
                        @Override
                        public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                            String[] rekap = response.body().getMessage().split(",");
                            entries.clear();
                            int start = 0;
                            for (String s : rekap) {
                                int jumlah = Integer.parseInt(s);
                                entries.add(new BarEntry(jumlah*1f, start));
                                start++;
                            }

                            BarDataSet bardataset = new BarDataSet(entries, "Elektabilitas UKM");
                            barchart.animateY(5000);
                            BarData data = new BarData(months, bardataset);
                            bardataset.setColors(ColorTemplate.COLORFUL_COLORS);
                            barchart.setData(data);
                            barchart.setVisibleXRangeMaximum(5);
                            barchart.notifyDataSetChanged();
                        }

                        @Override
                        public void onFailure(Call<UkmModel> call, Throwable t) {
                            Toast.makeText(ElektabilitasUkmActivity.this, t.toString(), Toast.LENGTH_SHORT).show();
                            t_ukm.setSelection(0);
                        }
                    });
                }else{
                    entries.clear();
                    int start = 0;
                    for (start = 0; start <12; start++) {
                        entries.add(new BarEntry(0*1f, start));
                    }

                    BarDataSet bardataset = new BarDataSet(entries, "Elektabilitas UKM");
                    barchart.animateY(5000);
                    BarData data = new BarData(months, bardataset);
                    bardataset.setColors(ColorTemplate.COLORFUL_COLORS);
                    barchart.setData(data);
                    barchart.setVisibleXRangeMaximum(5);
                    barchart.notifyDataSetChanged();
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                entries.clear();
                int start = 0;
                for (start = 0; start <12; start++) {
                    entries.add(new BarEntry(0*1f, start));
                }

                BarDataSet bardataset = new BarDataSet(entries, "Elektabilitas UKM");
                barchart.animateY(5000);
                BarData data = new BarData(months, bardataset);
                bardataset.setColors(ColorTemplate.COLORFUL_COLORS);
                barchart.setData(data);
                barchart.setVisibleXRangeMaximum(5);
                barchart.notifyDataSetChanged();
            }
        });
    }

    private void getUkm(){
        final UkmApi ukmApi= Retro.ukmRetro();
        ukmApi.getUkm().enqueue(new Callback<ArrayList<UkmModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<UkmModel>> call, Response<ArrayList<UkmModel>> response) {
                if(!response.body().toString().equals("[]")){
                    for(int i = 0; i < response.body().toArray().length; i++){
                        ukms.add(response.body().get(i).getKd_ukm()+" - "+response.body().get(i).getNama_ukm());
                    }
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<UkmModel>> call, Throwable t) {
                Toast.makeText(ElektabilitasUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
