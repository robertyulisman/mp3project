package com.zgenit.unim.adapter;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.agenda.AgendaDetailActivity;
import com.zgenit.unim.api.AgendaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.AgendaModel;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AnggotaAgendaAdapter extends RecyclerView.Adapter<AnggotaAgendaAdapter.MyViewHolder> {

    private Context context;
    private List<AgendaModel> AgendaModels;
    String role;
    ProgressDialog progressDialog;

    public AnggotaAgendaAdapter(Context context, ArrayList<AgendaModel> AgendaModels) {
        this.context = context;
        this.AgendaModels = AgendaModels;
    }

    @NonNull
    @Override
    public AnggotaAgendaAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.anggota_agenda_list,
                viewGroup, false);
        return new AnggotaAgendaAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final AnggotaAgendaAdapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.ukm.setText(AgendaModels.get(i).getUkm());
        myViewHolder.nama.setText(AgendaModels.get(i).getNama_keg());
        myViewHolder.tanggal.setText(AgendaModels.get(i).getTgl_keg());
        myViewHolder.presensi.setText(AgendaModels.get(i).getStatus());
    }

    @Override
    public int getItemCount() {
        return AgendaModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.agenda)
        LinearLayout agenda;
        @BindView(R.id.ukm)
        TextView ukm;
        @BindView(R.id.nama)
        TextView nama;
        @BindView(R.id.tanggal)
        TextView tanggal;
        @BindView(R.id.presensi)
        TextView presensi;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}