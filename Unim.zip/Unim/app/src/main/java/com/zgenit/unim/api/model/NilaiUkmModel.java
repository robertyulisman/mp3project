package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class NilaiUkmModel {
    @SerializedName("kd_nilai_ukm")
    @Expose
    private String kd_nilai_ukm;
    @SerializedName("kd_ukm")
    @Expose
    private String kd_ukm;
    @SerializedName("nilai_rekap")
    @Expose
    private String nilai_rekap;
    @SerializedName("status")
    @Expose
    private String status;
    @SerializedName("ukm")
    @Expose
    private String ukm;
    @SerializedName("jml_keg")
    @Expose
    private String jml_keg;
    @SerializedName("code")
    @Expose
    private Integer code;
    @SerializedName("message")
    @Expose
    private String message;

    public String getKd_nilai_ukm() { return kd_nilai_ukm; }
    public String getKd_ukm() { return kd_ukm; }
    public String getUkm() { return ukm; }
    public String getJml_keg() { return jml_keg; }
    public String getNilai() { return nilai_rekap; }
    public String getStatus() { return status; }
    public Integer getCode() { return code; }
    public String getMessage() { return message; }
}
