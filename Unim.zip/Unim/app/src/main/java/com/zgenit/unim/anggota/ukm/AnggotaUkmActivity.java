package com.zgenit.unim.anggota.ukm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.adapter.UkmAdapter;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AnggotaUkmActivity extends AppCompatActivity {

    @BindView(R.id.rv_ukm)
    RecyclerView rv_ukm;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.search)
    EditText search;
    @BindView(R.id.search2)
    Spinner search2;
    ArrayList<UkmModel> ukmModelArrayList, ukmFilters, ukmAll;
    UkmAdapter ukmAdapter;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anggota_ukm);
        ButterKnife.bind(this);

        message.setText("Sedang Memproses...");

        getUkm();

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnggotaUkmActivity.this, MainActivity.class));
            }
        });
    }

    private void getUkm(){
        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        String id_anggota = sharedPreferences.getString("id","");
        final UkmApi ukmApi= Retro.ukmRetro();
        ukmApi.getMine(id_anggota).enqueue(new Callback<ArrayList<UkmModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<UkmModel>> call, Response<ArrayList<UkmModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    ukmModelArrayList = new ArrayList<>();
                    ukmModelArrayList = response.body();
                    ukmAdapter = new UkmAdapter(AnggotaUkmActivity.this, ukmModelArrayList, "anggota");
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(AnggotaUkmActivity.this);
                    rv_ukm.setLayoutManager(layoutManager);
                    rv_ukm.setAdapter(ukmAdapter);
                }
                searchFunction();
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<UkmModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(AnggotaUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                searchFunction();
            }
        });
    }

    public void searchData(String text, String filter)
    {
        ukmFilters = new ArrayList<>();
        for(UkmModel ukmModel: ukmAll){
            if(filter.equals("Nama")){
                if(ukmModel.getNama_ukm().toLowerCase().contains(text.toLowerCase())){
                    ukmFilters.add(ukmModel);
                }
            }else if(filter.equals("Kode")){
                if(ukmModel.getKd_ukm().toLowerCase().contains(text.toLowerCase())){
                    ukmFilters.add(ukmModel);
                }
            }
        }
        ukmModelArrayList = ukmFilters;
        ukmAdapter.filterList(ukmFilters);
        ukmAdapter.notifyDataSetChanged();
    }

    public void searchFunction(){
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchData(s.toString(), search2.getSelectedItem().toString());
            }
        });

        search2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                searchData(search.getText().toString(), search2.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }
}
