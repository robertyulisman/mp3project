package com.zgenit.unim.api;

public class UriApi {
//    public static String BASE_URL = "http://192.168.43.20/projek/unim/";
    public static String BASE_URL = "http://ukmunim.site/index.php/";
//    public static String IMG_URL = BASE_URL+"foto/";
    public static String IMG_URL = "http://ukmunim.site/foto/";
}
