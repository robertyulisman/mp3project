package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class MahasiswaModel {
        @SerializedName("nim")
        @Expose
        private String nim;
        @SerializedName("pass")
        @Expose
        private String pass;
        @SerializedName("nama")
        @Expose
        private String nama;
        @SerializedName("alamat")
        @Expose
        private String alamat;
        @SerializedName("j_kel")
        @Expose
        private String j_kel;
        @SerializedName("ttl")
        @Expose
        private String ttl;
        @SerializedName("code")
        @Expose
        private Integer code;
        @SerializedName("message")
        @Expose
        private String message;

        public String getNim() { return nim; }
        public String getPass() { return pass; }
        public String getNama() { return nama; }
        public String getAlamat() { return alamat; }
        public String getJkel() { return j_kel; }
        public String getTtl() { return ttl; }
        public Integer getCode() { return code; }
        public String getMessage() { return message; }
}
