package com.zgenit.unim.adapter;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.AuthActivity;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.agenda.AgendaDetailActivity;
import com.zgenit.unim.api.AgendaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.AgendaModel;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AgendaAdapter extends RecyclerView.Adapter<AgendaAdapter.MyViewHolder> {

    private Context context;
    private List<AgendaModel> AgendaModels;
    String role;
    ProgressDialog progressDialog;

    public AgendaAdapter(Context context, ArrayList<AgendaModel> AgendaModels,String role) {
        this.context = context;
        this.AgendaModels = AgendaModels;
        this.role = role;
    }

    @NonNull
    @Override
    public AgendaAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.agenda_list,
                viewGroup, false);
        return new AgendaAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final AgendaAdapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.ukm.setText(AgendaModels.get(i).getUkm());
        myViewHolder.nama.setText(AgendaModels.get(i).getNama_keg());
        myViewHolder.tanggal.setText(AgendaModels.get(i).getTgl_keg());
        myViewHolder.agenda.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(v.getContext(), AgendaDetailActivity.class);
                if(role.equals("pengajuan")){
                    intent.putExtra("pengajuan", true);
                    intent.putExtra("kd_agenda", AgendaModels.get(i).getId());
                }else{
                    intent.putExtra("pengajuan", false);
                    intent.putExtra("kd_agenda", AgendaModels.get(i).getKd_agenda());
                }
                myViewHolder.itemView.getContext().startActivity(intent);
            }
        });
        progressDialog = new ProgressDialog(myViewHolder.itemView.getContext());
        progressDialog.setMessage("Sedang memproses");
        progressDialog.setCancelable(false);
        SharedPreferences sharedPreferences = myViewHolder.itemView.getContext().getSharedPreferences("Unim", Context.MODE_PRIVATE);
        final String id_anggota = sharedPreferences.getString("id", "");
        myViewHolder.ikuti.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(final View v) {
                progressDialog.show();
                AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                builder.setTitle("Konfirmasi");
                builder.setMessage("Yakin ingin mengikuti Kegiatan ?");
                builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
                    public void onClick(DialogInterface dialogInterface, int id) {
                        progressDialog.show();
                        final AgendaApi agendaApi = Retro.agendaRetro();
                        agendaApi.ikutAgenda(AgendaModels.get(i).getKd_agenda(),id_anggota).enqueue(new Callback<UkmModel>() {
                            @Override
                            public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                                progressDialog.dismiss();
                                if(response.body().getCode() == 1){
                                    Toast.makeText(v.getContext(), "Berhasil Mengikuti Kegiatan", Toast.LENGTH_SHORT).show();
                                }
                            }

                            @Override
                            public void onFailure(Call<UkmModel> call, Throwable t) {
                                progressDialog.dismiss();
                                Toast.makeText(v.getContext(), "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });
                builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                    }
                });
                builder.show();
            }
        });
        if(this.role.equals("anggota")){
            myViewHolder.ikuti.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public int getItemCount() {
        return AgendaModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.agenda)
        LinearLayout agenda;
        @BindView(R.id.ukm)
        TextView ukm;
        @BindView(R.id.nama)
        TextView nama;
        @BindView(R.id.tanggal)
        TextView tanggal;
        @BindView(R.id.ikuti)
        TextView ikuti;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }
}