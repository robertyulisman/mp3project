package com.zgenit.unim.anggota.pengaturan;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.anggota.pengaturan.saran.BuatSaranActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class AnggotaPengaturanActivity extends AppCompatActivity {

    @BindView(R.id.profile)
    LinearLayout profile;
    @BindView(R.id.password)
    LinearLayout password;
    @BindView(R.id.saran)
    LinearLayout saran;
    @BindView(R.id.btn_back)
    ImageView btn_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anggota_pengaturan);
        ButterKnife.bind(this);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnggotaPengaturanActivity.this, MainActivity.class));
            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnggotaPengaturanActivity.this, AnggotaProfileActivity.class));
            }
        });
        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnggotaPengaturanActivity.this, UpdatePasswordActivity.class));
            }
        });
        saran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnggotaPengaturanActivity.this, BuatSaranActivity.class));
            }
        });
    }
}
