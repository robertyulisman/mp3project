package com.zgenit.unim;

import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Toast;

public class SplashActivity extends AppCompatActivity {

    String id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        Thread timer = new Thread(){
            public void run() {
                try {
                    sleep(2000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                finally {
                    final SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
                    id = sharedPreferences.getString("id", "");
                    System.out.println(id);
                    if(id.equals("")){
                        startActivity(new Intent(SplashActivity.this, AuthActivity.class));
                    }else {
                        startActivity(new Intent(SplashActivity.this, MainActivity.class));
                    }
                    finish();
                }
            }
        };
        timer.start();
    }
}
