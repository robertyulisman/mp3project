package com.zgenit.unim.api;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class Retro{
    private static Retrofit retro = null;
    private static final String base_url = UriApi.BASE_URL;

    private static Retrofit getClient() {

        HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .build();

        if (retro == null) {
            retro = new Retrofit.Builder()
                    .baseUrl(base_url)
                    .addConverterFactory(GsonConverterFactory.create())
                    .client(client)
                    .build();
        }

        return retro;
    }

    public static AuthApi authRetro() {
        return getClient().create(AuthApi.class);
    }
    public static AnggotaApi anggotaRetro() {
        return getClient().create(AnggotaApi.class);
    }
    public static UkmApi ukmRetro() {
        return getClient().create(UkmApi.class);
    }
    public static AgendaApi agendaRetro() {
        return getClient().create(AgendaApi.class);
    }
    public static NilaiUkmApi nilaiUkmRetro() {
        return getClient().create(NilaiUkmApi.class);
    }
    public static SaranApi saranRetro() {
        return getClient().create(SaranApi.class);
    }
    public static UserApi userRetro() {
        return getClient().create(UserApi.class);
    }
    public static StrukturalApi strukturalRetro() {
        return getClient().create(StrukturalApi.class);
    }
}
