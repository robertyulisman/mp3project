package com.zgenit.unim.pembina.elektabilitas;

import android.annotation.SuppressLint;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.admin.elektabilitas.ElektabilitasUkmActivity;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PembinaElektabilitasActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.barchart)
    BarChart barchart;
    List<BarEntry> entries = new ArrayList<>();
    ArrayList<String> months;
    String kd_ukm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembina_elektabilitas);
        ButterKnife.bind(this);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaElektabilitasActivity.this, MainActivity.class));
            }
        });

        kd_ukm = getIntent().getStringExtra("kd_ukm");
        final UkmApi ukmApi = Retro.ukmRetro();
        ukmApi.getRekap(kd_ukm).enqueue(new Callback<UkmModel>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                String[] rekap = response.body().getMessage().split(",");
                entries.clear();
                int start = 0;
                for (String s : rekap) {
                    int jumlah = Integer.parseInt(s);
                    entries.add(new BarEntry(jumlah*1f, start));
                    start++;
                }

                BarDataSet bardataset = new BarDataSet(entries, "Elektabilitas UKM");
                barchart.animateY(5000);
                BarData data = new BarData(months, bardataset);
                bardataset.setColors(ColorTemplate.COLORFUL_COLORS);
                barchart.setData(data);
                barchart.setVisibleXRangeMaximum(5);
                barchart.notifyDataSetChanged();
            }

            @Override
            public void onFailure(Call<UkmModel> call, Throwable t) {
                Toast.makeText(PembinaElektabilitasActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });

        months = new ArrayList<String>();

        months.add("Jan");
        months.add("Feb");
        months.add("Mar");
        months.add("Apr");
        months.add("Mei");
        months.add("Jun");
        months.add("Jul");
        months.add("Agu");
        months.add("Sep");
        months.add("Okt");
        months.add("Nov");
        months.add("Des");

        BarDataSet bardataset = new BarDataSet(entries, "Elektabilitas UKM");
        barchart.animateY(5000);
        BarData data = new BarData(months, bardataset);
        bardataset.setColors(ColorTemplate.COLORFUL_COLORS);
        barchart.setData(data);
        barchart.setVisibleXRangeMaximum(5);
        barchart.notifyDataSetChanged();
    }
}
