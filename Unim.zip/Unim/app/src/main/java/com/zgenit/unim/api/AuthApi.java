package com.zgenit.unim.api;

import com.zgenit.unim.api.model.UserModel;

import java.util.ArrayList;

import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.PUT;
import retrofit2.http.Part;
import retrofit2.http.Path;

public interface AuthApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<UserModel> getOneRute();

    @FormUrlEncoded
    @POST("auth/register")
    Call<UserModel> register(
            @Field("nim") String nim,
            @Field("pass") String pass,
            @Field("no_telp") String no_telp,
            @Field("fakultas") String fakultas,
            @Field("prodi") String prodi
    );

    @FormUrlEncoded
    @POST("auth/login")
    Call<UserModel> login(
            @Field("user") String user,
            @Field("pass") String pass,
            @Field("role") String role
    );
}

