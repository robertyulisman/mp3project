package com.zgenit.unim.admin.saran;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.AuthActivity;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.SaranApi;
import com.zgenit.unim.api.model.SaranModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailSaranActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.subjek)
    TextView subjek;
    @BindView(R.id.pesan)
    TextView pesan;
    @BindView(R.id.pengirim)
    TextView pengirim;
    @BindView(R.id.hapus)
    Button hapus;
    int id_saran;
    ProgressDialog progressDialog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_saran);
        ButterKnife.bind(this);
        id_saran = getIntent().getIntExtra("id_saran", 0);
        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang memproses");
        progressDialog.setCancelable(false);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DetailSaranActivity.this, SaranMaukActivity.class));
            }
        });

        hapus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(id_saran != 0) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(DetailSaranActivity.this);
                    builder.setTitle("Konfirmasi Hapus");
                    builder.setMessage("Yakin ingin menghapus Pesan ?");
                    builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialogInterface, int id) {
                            progressDialog.show();
                            final SaranApi saranApi = Retro.saranRetro();
                            saranApi.deleteSaran(id_saran).enqueue(new Callback<SaranModel>() {
                                @Override
                                public void onResponse(Call<SaranModel> call, Response<SaranModel> response) {
                                    progressDialog.dismiss();
                                    if (response.body().getCode() == 1) {
                                        Toast.makeText(DetailSaranActivity.this, "Data Berhasil Dihapus", Toast.LENGTH_SHORT).show();
                                    } else {
                                        Toast.makeText(DetailSaranActivity.this, "Data Tidak Ditemukan", Toast.LENGTH_SHORT).show();
                                    }
                                    Handler handler = new Handler();
                                    handler.postDelayed(new Runnable() {
                                        @Override
                                        public void run() {
                                            startActivity(new Intent(DetailSaranActivity.this, SaranMaukActivity.class));
                                        }
                                    },1000);
                                }

                                @Override
                                public void onFailure(Call<SaranModel> call, Throwable t) {
                                    progressDialog.dismiss();
                                    Toast.makeText(DetailSaranActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    });
                    builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                }
            }
        });

        getSaran(id_saran);
    }
    protected  void getSaran(int id_saran){
        progressDialog.show();
        final SaranApi saranApi = Retro.saranRetro();
        saranApi.oneSaran(id_saran).enqueue(new Callback<SaranModel>() {
            @Override
            public void onResponse(Call<SaranModel> call, Response<SaranModel> response) {
                progressDialog.dismiss();
                if(response.body().toString().equals("[]")){
                    Toast.makeText(DetailSaranActivity.this, "Data Tidak Ditemukan", Toast.LENGTH_SHORT).show();
                    Handler handler = new Handler();
                    handler.postDelayed(new Runnable() {
                        @Override
                        public void run() {
                            startActivity(new Intent(DetailSaranActivity.this, SaranMaukActivity.class));
                        }
                    },1000);
                }else{
                    subjek.setText(response.body().getSubject());
                    pesan.setText(response.body().getPesan());
                    pengirim.setText(response.body().getNama());
                }
            }

            @Override
            public void onFailure(Call<SaranModel> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(DetailSaranActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
