package com.zgenit.unim.pembina.agenda;

import android.annotation.SuppressLint;
import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.adapter.AgendaAdapter;
import com.zgenit.unim.api.AgendaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.AgendaModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PembinaAgendaActivity extends AppCompatActivity {

    @BindView(R.id.rv_agenda)
    RecyclerView rv_agenda;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String kd_ukm;
    ArrayList<AgendaModel> agendaModelArrayList;
    AgendaAdapter agendaAdapter;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembina_agenda);
        ButterKnife.bind(this);

        kd_ukm = getIntent().getStringExtra("kd_ukm");
        message.setText("Sedang Memproses...");

        getAgenda(kd_ukm);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(PembinaAgendaActivity.this, MainActivity.class));
            }
        });
    }

    private void getAgenda(String kd_ukm){
        final AgendaApi agendaApi= Retro.agendaRetro();
        agendaApi.getPerUkm(kd_ukm).enqueue(new Callback<ArrayList<AgendaModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<AgendaModel>> call, Response<ArrayList<AgendaModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    agendaModelArrayList = new ArrayList<>();
                    agendaModelArrayList = response.body();
                    agendaAdapter = new AgendaAdapter(PembinaAgendaActivity.this, agendaModelArrayList, "pembina");
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(PembinaAgendaActivity.this);
                    rv_agenda.setLayoutManager(layoutManager);
                    rv_agenda.setAdapter(agendaAdapter);
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<AgendaModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(PembinaAgendaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
