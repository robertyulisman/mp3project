package com.zgenit.unim.admin;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.admin.mahasiswa.DataMahasiswaActivity;
import com.zgenit.unim.admin.pembina.DataPembinaActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class InfoAnggotaActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.mahasiswa)
    LinearLayout mahasiswa;
    @BindView(R.id.pembina)
    LinearLayout pembina;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_anggota);
        ButterKnife.bind(this);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoAnggotaActivity.this, MainActivity.class));
            }
        });
        mahasiswa.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoAnggotaActivity.this, DataMahasiswaActivity.class));
            }
        });
        pembina.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(InfoAnggotaActivity.this, DataPembinaActivity.class));
            }
        });
    }
}
