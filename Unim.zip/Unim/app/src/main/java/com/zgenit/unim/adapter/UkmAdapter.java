package com.zgenit.unim.adapter;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.makeramen.roundedimageview.RoundedImageView;
import com.zgenit.unim.R;
import com.zgenit.unim.admin.pembina.EditPembinaActivity;
import com.zgenit.unim.anggota.struktur.DetailUkmActivity;
import com.zgenit.unim.anggota.struktural.FormStrukturalActivity;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.UriApi;
import com.zgenit.unim.api.model.MahasiswaModel;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class UkmAdapter extends RecyclerView.Adapter<UkmAdapter.MyViewHolder> {

    private Context context;
    private List<UkmModel> UkmModels;
    String role;

    public UkmAdapter(Context context, ArrayList<UkmModel> UkmModels, String role) {
        this.context = context;
        this.UkmModels = UkmModels;
        this.role = role;
    }

    @NonNull
    @Override
    public UkmAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(context).inflate(R.layout.ukm_list,
                viewGroup, false);
        return new UkmAdapter.MyViewHolder(view);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onBindViewHolder(@NonNull final UkmAdapter.MyViewHolder myViewHolder, final int i) {
        myViewHolder.nama.setText(UkmModels.get(i).getNama_ukm());
        myViewHolder.pem.setText("Pembina : "+UkmModels.get(i).getPembina());
        if(UkmModels.get(i).getStruktural() == null){
            myViewHolder.struk.setText("Struktural : -");
        }else{
            myViewHolder.struk.setText("Struktural : "+UkmModels.get(i).getStruktural());
        }
        Glide.with(myViewHolder.itemView.getContext()).load(UriApi.IMG_URL+"ukm/"+UkmModels.get(i).getPhoto())
                .error(R.color.colorPhoto)
                .diskCacheStrategy(DiskCacheStrategy.ALL)
                .into(myViewHolder.photo);
        if(role.equals("anggota")){
            myViewHolder.daftar.setVisibility(View.VISIBLE);
            myViewHolder.daftar.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(final View v) {
                    AlertDialog.Builder builder = new AlertDialog.Builder(v.getContext());
                    builder.setTitle("Konfirmasi");
                    builder.setMessage("Yakin ingin bergabung Ukm ?");
                    builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
                        public void onClick(DialogInterface dialogInterface, int id) {
                            SharedPreferences sharedPreferences = v.getContext().getSharedPreferences("Unim", Context.MODE_PRIVATE);
                            String id_anggota = sharedPreferences.getString("id", "");
                            final UkmApi ukmApi = Retro.ukmRetro();
                            ukmApi.daftarUkm(id_anggota, UkmModels.get(i).getKd_ukm()).enqueue(new Callback<UkmModel>() {
                                @Override
                                public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                                    if (response.body().getCode() == 1) {
                                        Toast.makeText(v.getContext(), "Berhasil Mengikuti Ukm", Toast.LENGTH_SHORT).show();
                                    }
                                }

                                @Override
                                public void onFailure(Call<UkmModel> call, Throwable t) {
                                    Toast.makeText(v.getContext(), "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    });
                    builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialog, int which) {

                        }
                    });
                    builder.show();
                }
            });
        }
        if(role.equals("detail")){
            myViewHolder.ukm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(), DetailUkmActivity.class);
                    intent.putExtra("kd_ukm", UkmModels.get(i).getKd_ukm());
                    v.getContext().startActivity(intent);
                }
            });
        }
        if(role.equals("struktural")){
            myViewHolder.ukm.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent(v.getContext(), FormStrukturalActivity.class);
                    intent.putExtra("kd_ukm", UkmModels.get(i).getKd_ukm());
                    v.getContext().startActivity(intent);
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return UkmModels.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        @BindView(R.id.ukm)
        LinearLayout ukm;
        @BindView(R.id.nama)
        TextView nama;
        @BindView(R.id.pem)
        TextView pem;
        @BindView(R.id.struk)
        TextView struk;
        @BindView(R.id.daftar)
        TextView daftar;
        @BindView(R.id.photo)
        RoundedImageView photo;
//        @BindView(R.id.struk)
//        Button btn_edit;
//        @BindView(R.id.btn_delete)
//        Button btn_delete;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            ButterKnife.bind(this, itemView);
        }
    }

    public void filterList(List<UkmModel> ukmModels)
    {
        this.UkmModels= ukmModels;
        notifyDataSetChanged();
    }
}
