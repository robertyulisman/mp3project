package com.zgenit.unim.struktural.ukm;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.makeramen.roundedimageview.RoundedImageView;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.UriApi;
import com.zgenit.unim.api.model.UkmModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class StrukturalUkmActivity extends AppCompatActivity {

    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.ukm)
    TextView ukm;
    @BindView(R.id.deskripsi)
    TextView deskripsi;
    @BindView(R.id.pembina)
    TextView pembina;
    @BindView(R.id.ketua)
    TextView ketua;
    @BindView(R.id.anggota)
    TextView anggota;
    @BindView(R.id.fab_edit)
    FloatingActionButton fab_edit;
    @BindView(R.id.photo)
    RoundedImageView photo;
    String kd_ukm;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_struktural_ukm);
        ButterKnife.bind(this);

        kd_ukm = getIntent().getStringExtra("kd_ukm");
        getDetail(kd_ukm);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StrukturalUkmActivity.this, MainActivity.class));
            }
        });
        fab_edit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(StrukturalUkmActivity.this, EditInfoUkmActivity.class);
                intent.putExtra("kd_ukm", kd_ukm);
                startActivity(new Intent(intent));
            }
        });
    }

    public void getDetail(String kd_ukm){
        final UkmApi ukmApi = Retro.ukmRetro();
        ukmApi.detailUkm(kd_ukm).enqueue(new Callback<UkmModel>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<UkmModel> call, Response<UkmModel> response) {
                if(response.body().getCode() == 1){
                    ukm.setText(response.body().getNama_ukm());
                    deskripsi.setText(response.body().getDeskripsi());;
                    pembina.setText(response.body().getPembina());
                    ketua.setText(response.body().getKetua());
                    anggota.setText(response.body().getJumlah()+" orang");
                    Glide.with(StrukturalUkmActivity.this).load(UriApi.IMG_URL+"ukm/"+response.body().getPhoto())
                            .error(R.color.colorPhoto)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .into(photo);
                }else{
                    Toast.makeText(StrukturalUkmActivity.this, "Data tidak ditemukan", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<UkmModel> call, Throwable t) {
                Toast.makeText(StrukturalUkmActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
