package com.zgenit.unim.struktural.agenda;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;
import android.support.v7.widget.AppCompatEditText;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.TimePicker;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.AgendaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.AgendaModel;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SAddAgendaActivity extends AppCompatActivity {

    @BindView(R.id.nama)
    AppCompatEditText t_nama;
    @BindView(R.id.jenis)
    AppCompatEditText t_jenis;
    @BindView(R.id.tanggal)
    AppCompatEditText t_tanggal;
    @BindView(R.id.jam)
    AppCompatEditText t_jam;
    @BindView(R.id.tempat)
    AppCompatEditText t_tempat;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String nama, jenis, tanggal, jam, tempat, kd_ukm, pengirim;
    ProgressDialog progressDialog;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sadd_agenda);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        SharedPreferences  sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        kd_ukm = sharedPreferences.getString("kd_ukm","");
        pengirim = sharedPreferences.getString("id","");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SAddAgendaActivity.this, MainActivity.class));
            }
        });

        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };

        t_tanggal.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    new DatePickerDialog(SAddAgendaActivity.this, date, myCalendar
                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                }
            }
        });

        t_jam.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    Calendar mcurrentTime = Calendar.getInstance();
                    int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                    int minute = mcurrentTime.get(Calendar.MINUTE);
                    TimePickerDialog mTimePicker;
                    mTimePicker = new TimePickerDialog(SAddAgendaActivity.this, new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                            t_jam.setText(selectedHour + ":" + selectedMinute);
                        }
                    }, hour, minute, true);//Yes 24 hour time
                    mTimePicker.setTitle("Tentukan Jam");
                    mTimePicker.show();
                }
            }
        });

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jenis = Objects.requireNonNull(t_jenis.getText()).toString();
                nama = Objects.requireNonNull(t_nama.getText()).toString();
                tanggal = Objects.requireNonNull(t_tanggal.getText()).toString();
                jam = Objects.requireNonNull(t_jam.getText()).toString();
                tempat = Objects.requireNonNull(t_tempat.getText()).toString();

                if(jenis.equals("") || nama.equals("") || tanggal.equals("") || jam.equals("") || tempat.equals("")){
                    Toast.makeText(SAddAgendaActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    final AgendaApi agendaApi= Retro.agendaRetro();
                    agendaApi.ajukanAgenda(pengirim,kd_ukm, nama, jenis, tanggal, jam, tempat).enqueue(new Callback<AgendaModel>() {
                        @Override
                        public void onResponse(Call<AgendaModel> call, Response<AgendaModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1 ){
                                Toast.makeText(SAddAgendaActivity.this, "Data sukses ditambahkan", Toast.LENGTH_SHORT).show();
                                t_nama.setText("");
                                t_jenis.setText("");
                                t_tempat.setText("");
                                t_tanggal.setText("");
                                t_jam.setText("");
                            }else{
                                Toast.makeText(SAddAgendaActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<AgendaModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(SAddAgendaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private void updateLabel() {
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        t_tanggal.setText(sdf.format(myCalendar.getTime()));
    }
}
