package com.zgenit.unim.api;

import com.zgenit.unim.api.model.NilaiUkmModel;

import java.util.ArrayList;

import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.Headers;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface NilaiUkmApi {

    @Headers({
            "Content-Type: application/json"
    })

    @GET("rute/one.php")
    Call<NilaiUkmModel> getOneRute();

    @GET("nilaiukm/index")
    Call<ArrayList<NilaiUkmModel>> getNilai();

    @GET("nilaiukm/get/{kd_nilai_ukm}")
    Call<NilaiUkmModel> oneNilai(@Path("kd_nilai_ukm") String kd_nilai_ukm);

    @FormUrlEncoded
    @POST("nilaiukm/add")
    Call<NilaiUkmModel> addNilai(
            @Field("kd_ukm") String kd_ukm,
            @Field("jml_keg") String jml_keg,
            @Field("status") String status,
            @Field("nilai_rekap") String nilai_rekap
    );
}

