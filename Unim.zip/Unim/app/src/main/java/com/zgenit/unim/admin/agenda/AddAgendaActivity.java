package com.zgenit.unim.admin.agenda;

import android.annotation.SuppressLint;
import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;;
import androidx.appcompat.widget.AppCompatEditText;

import com.zgenit.unim.R;
import com.zgenit.unim.api.AgendaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.AgendaModel;
import com.zgenit.unim.api.model.UkmModel;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Objects;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AddAgendaActivity extends AppCompatActivity {

    @BindView(R.id.ukm)
    Spinner t_ukm;
    @BindView(R.id.nama)
    AppCompatEditText t_nama;
    @BindView(R.id.jenis)
    AppCompatEditText t_jenis;
    @BindView(R.id.tanggal)
    AppCompatEditText t_tanggal;
    @BindView(R.id.jam)
    AppCompatEditText t_jam;
    @BindView(R.id.tempat)
    AppCompatEditText t_tempat;
    @BindView(R.id.btn_simpan)
    Button btn_simpan;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String nama, jenis, tanggal, jam, tempat;
    ProgressDialog progressDialog;
    List<String> ukms;
    Calendar myCalendar;
    DatePickerDialog.OnDateSetListener date;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_agenda);
        ButterKnife.bind(this);

        progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Sedang Memproses");
        progressDialog.setCancelable(false);

        ukms = new ArrayList<>();
        ukms.add("Pilih UKM");

        getUkm();

        ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item, ukms);
        arrayAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        t_ukm.setAdapter(arrayAdapter);


        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AddAgendaActivity.this, AgendaKegiatanActivity.class));
            }
        });

        myCalendar = Calendar.getInstance();
        date = new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear,
                                  int dayOfMonth) {
                // TODO Auto-generated method stub
                myCalendar.set(Calendar.YEAR, year);
                myCalendar.set(Calendar.MONTH, monthOfYear);
                myCalendar.set(Calendar.DAY_OF_MONTH, dayOfMonth);
                updateLabel();
            }
        };

        t_tanggal.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    new DatePickerDialog(AddAgendaActivity.this, date, myCalendar
                            .get(Calendar.YEAR), myCalendar.get(Calendar.MONTH),
                            myCalendar.get(Calendar.DAY_OF_MONTH)).show();
                }
            }
        });

        t_jam.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if(hasFocus){
                    Calendar mcurrentTime = Calendar.getInstance();
                    int hour = mcurrentTime.get(Calendar.HOUR_OF_DAY);
                    int minute = mcurrentTime.get(Calendar.MINUTE);
                    TimePickerDialog mTimePicker;
                    mTimePicker = new TimePickerDialog(AddAgendaActivity.this, new TimePickerDialog.OnTimeSetListener() {

                        @Override
                        public void onTimeSet(TimePicker timePicker, int selectedHour, int selectedMinute) {
                            t_jam.setText(selectedHour + ":" + selectedMinute);
                        }
                    }, hour, minute, true);//Yes 24 hour time
                    mTimePicker.setTitle("Tentukan Jam");
                    mTimePicker.show();
                }
            }
        });

        btn_simpan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                jenis = Objects.requireNonNull(t_jenis.getText()).toString();
                nama = Objects.requireNonNull(t_nama.getText()).toString();
                tanggal = Objects.requireNonNull(t_tanggal.getText()).toString();
                jam = Objects.requireNonNull(t_jam.getText()).toString();
                tempat = Objects.requireNonNull(t_tempat.getText()).toString();
                String s_ukm = t_ukm.getSelectedItem().toString();
                String[] ukm = s_ukm.split("-");

                if(jenis.equals("") || nama.equals("") || tanggal.equals("") || jam.equals("") || s_ukm.equals("Pilih UKM") || tempat.equals("")){
                    Toast.makeText(AddAgendaActivity.this, "Semua field harus diisi", Toast.LENGTH_SHORT).show();
                }else{
                    progressDialog.show();
                    final AgendaApi agendaApi= Retro.agendaRetro();
                    agendaApi.addAgenda(ukm[0].trim(), nama, jenis, tanggal, jam, tempat).enqueue(new Callback<AgendaModel>() {
                        @Override
                        public void onResponse(Call<AgendaModel> call, Response<AgendaModel> response) {
                            progressDialog.dismiss();
                            if(response.body().getCode() == 1 ){
                                Toast.makeText(AddAgendaActivity.this, "Data sukses ditambahkan", Toast.LENGTH_SHORT).show();
                                t_nama.setText("");
                                t_jenis.setText("");
                                t_tempat.setText("");
                                t_tanggal.setText("");
                                t_jam.setText("");
                                t_ukm.setSelection(0);
                            }else{
                                Toast.makeText(AddAgendaActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }

                        @Override
                        public void onFailure(Call<AgendaModel> call, Throwable t) {
                            progressDialog.dismiss();
                            Toast.makeText(AddAgendaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                        }
                    });
                }
            }
        });
    }

    private void getUkm(){
        final UkmApi ukmApi= Retro.ukmRetro();
        ukmApi.getUkm().enqueue(new Callback<ArrayList<UkmModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<UkmModel>> call, Response<ArrayList<UkmModel>> response) {
                if(!response.body().toString().equals("[]")){
                    for(int i = 0; i < response.body().toArray().length; i++){
                        ukms.add(response.body().get(i).getKd_ukm()+" - "+response.body().get(i).getNama_ukm());
                    }
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<UkmModel>> call, Throwable t) {
                Toast.makeText(AddAgendaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void updateLabel() {
        String myFormat = "yyyy-MM-dd";
        SimpleDateFormat sdf = new SimpleDateFormat(myFormat, Locale.US);
        t_tanggal.setText(sdf.format(myCalendar.getTime()));
    }
}
