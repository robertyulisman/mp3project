package com.zgenit.unim.agenda;

import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.AuthActivity;
import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.api.AgendaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.AgendaModel;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AgendaDetailActivity extends AppCompatActivity {

    @BindView(R.id.ukm)
    TextView ukm;
    @BindView(R.id.nama)
    TextView nama;
    @BindView(R.id.jenis)
    TextView jenis;
    @BindView(R.id.tanggal)
    TextView tanggal;
    @BindView(R.id.jam)
    TextView jam;
    @BindView(R.id.tempat)
    TextView tempat;
    @BindView(R.id.pengirim)
    TextView pengirim;
    @BindView(R.id.f_pengirim)
    LinearLayout f_pengirim;
    @BindView(R.id.f_btn)
    LinearLayout f_btn;
    @BindView(R.id.btn_konf)
    Button btn_konf;
    @BindView(R.id.btn_tolak)
    Button btn_tolak;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    String kd_agenda;
    Boolean is_pengajuan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agenda_detail);
        ButterKnife.bind(this);

        kd_agenda = getIntent().getStringExtra("kd_agenda");
        is_pengajuan = getIntent().getBooleanExtra("pengajuan", false);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AgendaDetailActivity.super.onBackPressed();
            }
        });
        if(is_pengajuan){
            f_pengirim.setVisibility(View.VISIBLE);
            f_btn.setVisibility(View.VISIBLE);

            btn_konf.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    konfirmasi("Diterima");
                }
            });
            btn_tolak.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    konfirmasi("Ditolak");
                }
            });
        }

        getAgenda(kd_agenda);
    }
    private void getAgenda(String kd_agenda) {
        if (is_pengajuan) {
            final AgendaApi agendaApi = Retro.agendaRetro();
            agendaApi.pengajuanDetail(kd_agenda).enqueue(new Callback<AgendaModel>() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onResponse(Call<AgendaModel> call, Response<AgendaModel> response) {
                    if (response.body().toString().equals("0")) {
                        Toast.makeText(AgendaDetailActivity.this, "Data Tidak Ditemukan", Toast.LENGTH_SHORT).show();
                    } else {
                        ukm.setText(response.body().getUkm());
                        nama.setText(response.body().getNama_keg());
                        jenis.setText(response.body().getJns_keg());
                        tanggal.setText(response.body().getTgl_keg());
                        jam.setText(response.body().getJam());
                        tempat.setText(response.body().getTempat());
                        pengirim.setText(response.body().getNama() + " (" + response.body().getJabatan() + ")");
                    }
                }

                @Override
                public void onFailure(Call<AgendaModel> call, Throwable t) {
                    Toast.makeText(AgendaDetailActivity.this, "Periksa Koneksi Internet", Toast.LENGTH_SHORT).show();
                }
            });
        } else {
            final AgendaApi agendaApi = Retro.agendaRetro();
            agendaApi.oneAgenda(kd_agenda).enqueue(new Callback<AgendaModel>() {
                @SuppressLint("SetTextI18n")
                @Override
                public void onResponse(Call<AgendaModel> call, Response<AgendaModel> response) {
                    if (response.body().toString().equals("0")) {
                        Toast.makeText(AgendaDetailActivity.this, "Data Tidak Ditemukan", Toast.LENGTH_SHORT).show();
                    } else {
                        ukm.setText(response.body().getUkm());
                        nama.setText(response.body().getNama_keg());
                        jenis.setText(response.body().getJns_keg());
                        tanggal.setText(response.body().getTgl_keg());
                        jam.setText(response.body().getJam());
                        tempat.setText(response.body().getTempat());
                    }
                }

                @Override
                public void onFailure(Call<AgendaModel> call, Throwable t) {
                    Toast.makeText(AgendaDetailActivity.this, "Periksa Koneksi Internet", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    public void konfirmasi(final String status){
        AlertDialog.Builder builder = new AlertDialog.Builder(AgendaDetailActivity.this);
        builder.setTitle("Konfirmasi");
        if(status.equals("Diterima")){
            builder.setMessage("Yakin ingin mengonfirmasi kegiatan ini ?");
        }else if(status.equals("Ditolak")){
            builder.setMessage("Yakin ingin menolak kegiatan ini ?");
        }
        builder.setPositiveButton("Ya",new DialogInterface.OnClickListener(){
            public void onClick(DialogInterface dialogInterface, int id) {
                final AgendaApi agendaApi = Retro.agendaRetro();
                agendaApi.setujuiAgenda(kd_agenda, status).enqueue(new Callback<AgendaModel>() {
                    @SuppressLint("SetTextI18n")
                    @Override
                    public void onResponse(Call<AgendaModel> call, Response<AgendaModel> response) {
                        if (response.body().toString().equals("0")) {
                            Toast.makeText(AgendaDetailActivity.this, "Data Tidak Ditemukan", Toast.LENGTH_SHORT).show();
                        } else {
                            Toast.makeText(AgendaDetailActivity.this, response.body().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }

                    @Override
                    public void onFailure(Call<AgendaModel> call, Throwable t) {
                        Toast.makeText(AgendaDetailActivity.this, "Periksa Koneksi Internet", Toast.LENGTH_SHORT).show();
                    }
                });
            }
        });
        builder.setNegativeButton("Batal", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

            }
        });
        builder.show();
    }
}
