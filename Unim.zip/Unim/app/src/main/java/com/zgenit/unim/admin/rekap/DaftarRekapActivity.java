package com.zgenit.unim.admin.rekap;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.adapter.NilaiUkmAdapter;
import com.zgenit.unim.admin.agenda.AddAgendaActivity;
import com.zgenit.unim.api.NilaiUkmApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.NilaiUkmModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DaftarRekapActivity extends AppCompatActivity {

    @BindView(R.id.rv_nilai)
    RecyclerView rv_nilai;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    ArrayList<NilaiUkmModel> NilaiUkmModelArrayList;
    NilaiUkmAdapter NilaiUkmAdapter;
    String role;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daftar_rekap);
        ButterKnife.bind(this);

        message.setText("Sedang Memproses...");

        getNilai();

        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        role = sharedPreferences.getString("role", "");

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(role.equals("Pembina") || role.equals("Struktural")){
                    startActivity(new Intent(DaftarRekapActivity.this, MainActivity.class));
                } else {
                    startActivity(new Intent(DaftarRekapActivity.this, RekapNilaiUkmActivity.class));
                }
            }
        });
    }

    private void getNilai(){
        final NilaiUkmApi NilaiUkmApi= Retro.nilaiUkmRetro();
        NilaiUkmApi.getNilai().enqueue(new Callback<ArrayList<NilaiUkmModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<NilaiUkmModel>> call, Response<ArrayList<NilaiUkmModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    NilaiUkmModelArrayList = new ArrayList<>();
                    NilaiUkmModelArrayList = response.body();
                    NilaiUkmAdapter = new NilaiUkmAdapter(DaftarRekapActivity.this, NilaiUkmModelArrayList);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(DaftarRekapActivity.this);
                    rv_nilai.setLayoutManager(layoutManager);
                    rv_nilai.setAdapter(NilaiUkmAdapter);
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<NilaiUkmModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(DaftarRekapActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
