package com.zgenit.unim.api.model;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class UkmModel {
        @SerializedName("kd_ukm")
        @Expose
        private String kd_ukm;
        @SerializedName("nama_ukm")
        @Expose
        private String nama_ukm;
        @SerializedName("deskripsi")
        @Expose
        private String deskripsi;
        @SerializedName("pembina")
        @Expose
        private String pembina;
        @SerializedName("struktural")
        @Expose
        private String struktural;
        @SerializedName("ketua")
        @Expose
        private String ketua;
        @SerializedName("wakil")
        @Expose
        private String wakil;
        @SerializedName("sekretaris")
        @Expose
        private String sekretaris;
        @SerializedName("bendahara")
        @Expose
        private String bendahara;
        @SerializedName("anggota")
        @Expose
        private String anggota;
        @SerializedName("jumlah")
        @Expose
        private int jumlah;
        @SerializedName("code")
        @Expose
        private Integer code;
        @SerializedName("message")
        @Expose
        private String message;
        @SerializedName("photo")
        @Expose
        private String photo;

        public String getKd_ukm() { return kd_ukm; }
        public String getPembina() { return pembina; }
        public String getStruktural() { return struktural; }
        public String getKetua() { return ketua; }
        public String getWakil() { return wakil; }
        public String getSekretaris() { return sekretaris; }
        public String getBendahara() { return bendahara; }
        public String getAnggota() { return anggota; }
        public int getJumlah() { return jumlah; }
        public String getNama_ukm() { return nama_ukm; }
        public Integer getCode() { return code; }
        public String getMessage() { return message; }
        public String getDeskripsi() { return deskripsi; }
        public String getPhoto() { return photo; }
}
