package com.zgenit.unim.admin.pembina;

import android.annotation.SuppressLint;
import android.content.Intent;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.R;
import com.zgenit.unim.adapter.PembinaAdapter;
import com.zgenit.unim.admin.InfoAnggotaActivity;
import com.zgenit.unim.admin.mahasiswa.AddMahasiswaActivity;
import com.zgenit.unim.api.AnggotaApi;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.model.MahasiswaModel;
import com.zgenit.unim.api.model.PembinaModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DataPembinaActivity extends AppCompatActivity {

    @BindView(R.id.rv_anggota)
    RecyclerView rv_anggota;
    @BindView(R.id.fab_add)
    FloatingActionButton fab_add;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    @BindView(R.id.search)
    EditText search;
    @BindView(R.id.search2)
    Spinner search2;
    ArrayList<PembinaModel> pembinaModelArrayList, pembinaFilters, pembinaAll;
    PembinaAdapter pembinaAdapter;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_data_pembina);
        ButterKnife.bind(this);

        message.setText("Sedang Memproses...");

        getPembina();

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DataPembinaActivity.this, InfoAnggotaActivity.class));
            }
        });

        fab_add.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(DataPembinaActivity.this, AddPembinaActivity.class));
            }
        });
    }

    private void getPembina(){
        final AnggotaApi anggotaApi = Retro.anggotaRetro();
        anggotaApi.getPembina().enqueue(new Callback<ArrayList<PembinaModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<PembinaModel>> call, Response<ArrayList<PembinaModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    pembinaModelArrayList = new ArrayList<>();
                    pembinaModelArrayList = response.body();
                    pembinaAll = pembinaModelArrayList;
                    pembinaAdapter = new PembinaAdapter(DataPembinaActivity.this, pembinaModelArrayList);
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(DataPembinaActivity.this);
                    rv_anggota.setLayoutManager(layoutManager);
                    rv_anggota.setAdapter(pembinaAdapter);
                }
                searchFunction();
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<PembinaModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(DataPembinaActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
                searchFunction();
            }
        });
    }

    public void searchData(String text, String filter)
    {
        pembinaFilters = new ArrayList<>();
        for(PembinaModel pembinaModel: pembinaAll){
            if(filter.equals("Nama")){
                if(pembinaModel.getNama().toLowerCase().contains(text.toLowerCase())){
                    pembinaFilters.add(pembinaModel);
                }
            }else if(filter.equals("Kode")){
                if(pembinaModel.getId_pem().toLowerCase().contains(text.toLowerCase())){
                    pembinaFilters.add(pembinaModel);
                }
            }
        }
        pembinaModelArrayList= pembinaFilters;
        pembinaAdapter.filterList(pembinaFilters);
        pembinaAdapter.notifyDataSetChanged();
    }

    public void searchFunction(){
        search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

            }

            @Override
            public void afterTextChanged(Editable s) {
                searchData(s.toString(), search2.getSelectedItem().toString());
            }
        });

        search2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                searchData(search.getText().toString(), search2.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });
    }

}
