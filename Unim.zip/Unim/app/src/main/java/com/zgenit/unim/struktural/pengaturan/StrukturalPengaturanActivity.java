package com.zgenit.unim.struktural.pengaturan;

import android.content.Intent;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.anggota.pengaturan.UpdatePasswordActivity;
import com.zgenit.unim.anggota.pengaturan.saran.BuatSaranActivity;
import com.zgenit.unim.pembina.pengaturan.PembinaProfileActivity;

import butterknife.BindView;
import butterknife.ButterKnife;

public class StrukturalPengaturanActivity extends AppCompatActivity {

    @BindView(R.id.profile)
    LinearLayout profile;
    @BindView(R.id.password)
    LinearLayout password;
    @BindView(R.id.saran)
    LinearLayout saran;
    @BindView(R.id.btn_back)
    ImageView btn_back;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_struktural_pengaturan);
        ButterKnife.bind(this);

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StrukturalPengaturanActivity.this, MainActivity.class));
            }
        });

        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StrukturalPengaturanActivity.this, PembinaProfileActivity.class));
            }
        });
        password.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StrukturalPengaturanActivity.this, UpdatePasswordActivity.class));
            }
        });
        saran.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(StrukturalPengaturanActivity.this, BuatSaranActivity.class));
            }
        });
    }
}
