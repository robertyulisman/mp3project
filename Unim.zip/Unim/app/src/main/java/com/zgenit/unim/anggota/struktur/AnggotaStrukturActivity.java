package com.zgenit.unim.anggota.struktur;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.zgenit.unim.MainActivity;
import com.zgenit.unim.R;
import com.zgenit.unim.adapter.UkmAdapter;
import com.zgenit.unim.api.Retro;
import com.zgenit.unim.api.UkmApi;
import com.zgenit.unim.api.model.UkmModel;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AnggotaStrukturActivity extends AppCompatActivity {

    @BindView(R.id.rv_ukm)
    RecyclerView rv_ukm;
    @BindView(R.id.message)
    TextView message;
    @BindView(R.id.btn_back)
    ImageView btn_back;
    ArrayList<UkmModel> ukmModelArrayList;
    UkmAdapter ukmAdapter;

    @SuppressLint("SetTextI18n")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_anggota_struktur);
        ButterKnife.bind(this);

        message.setText("Sedang Memproses...");

        getUkm();

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnggotaStrukturActivity.this, MainActivity.class));
            }
        });
    }

    private void getUkm(){
        SharedPreferences sharedPreferences = getSharedPreferences("Unim", MODE_PRIVATE);
        String id_anggota = sharedPreferences.getString("id", "");
        final UkmApi ukmApi= Retro.ukmRetro();
        ukmApi.getFollow(id_anggota).enqueue(new Callback<ArrayList<UkmModel>>() {
            @SuppressLint("SetTextI18n")
            @Override
            public void onResponse(Call<ArrayList<UkmModel>> call, Response<ArrayList<UkmModel>> response) {
                if(response.body().toString().equals("[]")){
                    message.setText("Belum ada Data");
                }else{
                    message.setVisibility(View.GONE);
                    ukmModelArrayList = new ArrayList<>();
                    ukmModelArrayList = response.body();
                    ukmAdapter = new UkmAdapter(AnggotaStrukturActivity.this, ukmModelArrayList, "detail");
                    RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(AnggotaStrukturActivity.this);
                    rv_ukm.setLayoutManager(layoutManager);
                    rv_ukm.setAdapter(ukmAdapter);
                }
            }

            @SuppressLint("SetTextI18n")
            @Override
            public void onFailure(Call<ArrayList<UkmModel>> call, Throwable t) {
                message.setText("Gagal memuat Data");
                Toast.makeText(AnggotaStrukturActivity.this, "Periksa Koneksi", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
